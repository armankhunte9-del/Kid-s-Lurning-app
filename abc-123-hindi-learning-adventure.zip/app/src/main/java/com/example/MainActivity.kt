package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.ParentGateDialog
import com.example.ui.components.ParticleConfetti
import com.example.ui.screens.*
import com.example.ui.theme.KidsIndigo
import com.example.ui.theme.KidsYellow
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.AppScreen
import com.example.viewmodel.KidsLearningViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: KidsLearningViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                KidsAppRoot(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun KidsAppRoot(
    viewModel: KidsLearningViewModel
) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val progress by viewModel.progress.collectAsStateWithLifecycle()
    val onboardingStep by viewModel.onboardingStep.collectAsStateWithLifecycle()

    // Numbers state
    val numberIndex by viewModel.numberIndex.collectAsStateWithLifecycle()
    val isNumberQuizMode by viewModel.isNumberQuizMode.collectAsStateWithLifecycle()
    val numberQuizIndex by viewModel.numberQuizIndex.collectAsStateWithLifecycle()

    // Alphabet state
    val alphabetIndex by viewModel.alphabetIndex.collectAsStateWithLifecycle()
    val isAlphabetQuizMode by viewModel.isAlphabetQuizMode.collectAsStateWithLifecycle()
    val alphabetQuizIndex by viewModel.alphabetQuizIndex.collectAsStateWithLifecycle()

    // Hindi state
    val hindiIndex by viewModel.hindiIndex.collectAsStateWithLifecycle()
    val isHindiQuizMode by viewModel.isHindiQuizMode.collectAsStateWithLifecycle()
    val hindiQuizIndex by viewModel.hindiQuizIndex.collectAsStateWithLifecycle()

    // Games state
    val selectedGame by viewModel.selectedGame.collectAsStateWithLifecycle()
    val findAnswerScore by viewModel.findAnswerScore.collectAsStateWithLifecycle()
    val findAnswerQuestionIndex by viewModel.findAnswerQuestionIndex.collectAsStateWithLifecycle()
    val countingTarget by viewModel.countingTarget.collectAsStateWithLifecycle()
    val countingEmoji by viewModel.countingEmoji.collectAsStateWithLifecycle()
    val countingOptions by viewModel.countingOptions.collectAsStateWithLifecycle()
    val selectedMatchLeft by viewModel.selectedMatchLeft.collectAsStateWithLifecycle()
    val matchedPairIds by viewModel.matchedPairIds.collectAsStateWithLifecycle()
    val hindiGameTargetIndex by viewModel.hindiGameTargetIndex.collectAsStateWithLifecycle()
    val hindiGameOptions by viewModel.hindiGameOptions.collectAsStateWithLifecycle()
    val memoryCards by viewModel.memoryCards.collectAsStateWithLifecycle()

    // Trophy challenge state
    val selectedTrophyTier by viewModel.selectedTrophyTier.collectAsStateWithLifecycle()
    val trophyQuestionIndex by viewModel.trophyQuestionIndex.collectAsStateWithLifecycle()
    val trophyScore by viewModel.trophyScore.collectAsStateWithLifecycle()
    val trophyCelebrationTier by viewModel.trophyCelebrationTier.collectAsStateWithLifecycle()

    // Confetti and Feedback
    val confettiTrigger by viewModel.confettiTrigger.collectAsStateWithLifecycle()
    val feedbackToast by viewModel.feedbackToast.collectAsStateWithLifecycle()

    // Parent Gate
    val isParentGateOpen by viewModel.isParentGateOpen.collectAsStateWithLifecycle()
    val parentGateQuestion by viewModel.parentGateQuestion.collectAsStateWithLifecycle()

    // Handle System Back button
    BackHandler(enabled = currentScreen != AppScreen.HOME && currentScreen != AppScreen.SPLASH) {
        when (currentScreen) {
            AppScreen.NUMBERS -> {
                if (isNumberQuizMode) viewModel.toggleNumberQuiz(false)
                else viewModel.navigateTo(AppScreen.HOME)
            }
            AppScreen.ALPHABET -> {
                if (isAlphabetQuizMode) viewModel.toggleAlphabetQuiz(false)
                else viewModel.navigateTo(AppScreen.HOME)
            }
            AppScreen.HINDI -> {
                if (isHindiQuizMode) viewModel.toggleHindiQuiz(false)
                else viewModel.navigateTo(AppScreen.HOME)
            }
            AppScreen.ONBOARDING -> viewModel.navigateTo(AppScreen.HOME)
            else -> viewModel.navigateTo(AppScreen.HOME)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        AnimatedContent(
            targetState = currentScreen,
            label = "screenNavTransition"
        ) { screen ->
            when (screen) {
                AppScreen.SPLASH -> SplashScreen()
                AppScreen.ONBOARDING -> OnboardingScreen(
                    currentStep = onboardingStep,
                    onNextStep = { viewModel.nextOnboardingStep() },
                    onSkip = { viewModel.finishOnboarding() }
                )
                AppScreen.HOME -> HomeScreen(
                    progress = progress,
                    onNavigateNumbers = {
                        viewModel.selectNumber(0)
                        viewModel.navigateTo(AppScreen.NUMBERS)
                    },
                    onNavigateAlphabet = {
                        viewModel.selectAlphabet(0)
                        viewModel.navigateTo(AppScreen.ALPHABET)
                    },
                    onNavigateHindi = {
                        viewModel.selectHindiLetter(0)
                        viewModel.navigateTo(AppScreen.HINDI)
                    },
                    onNavigateGames = { viewModel.navigateTo(AppScreen.GAMES) },
                    onNavigateTrophies = { viewModel.navigateTo(AppScreen.TROPHIES) },
                    onNavigateRewards = { viewModel.navigateTo(AppScreen.REWARDS) },
                    onNavigateSettings = { viewModel.navigateTo(AppScreen.SETTINGS) },
                    onNavigateParentDashboard = { viewModel.generateParentGateQuestion() },
                    onMascotSpeak = { message ->
                        viewModel.soundManager.speak(message)
                    }
                )
                AppScreen.NUMBERS -> NumbersScreen(
                    currentIndex = numberIndex,
                    starsCount = progress.stars,
                    isQuizMode = isNumberQuizMode,
                    quizIndex = numberQuizIndex,
                    onSelectNumber = { viewModel.selectNumber(it) },
                    onNextNumber = { viewModel.nextNumber() },
                    onPrevNumber = { viewModel.prevNumber() },
                    onSpeakNumber = { viewModel.speakCurrentNumber() },
                    onToggleQuiz = { viewModel.toggleNumberQuiz(it) },
                    onAnswerQuiz = { viewModel.answerNumberQuiz(it) },
                    onBackClick = { viewModel.navigateTo(AppScreen.HOME) },
                    onHomeClick = { viewModel.navigateTo(AppScreen.HOME) }
                )
                AppScreen.ALPHABET -> AlphabetScreen(
                    currentIndex = alphabetIndex,
                    starsCount = progress.stars,
                    isQuizMode = isAlphabetQuizMode,
                    quizIndex = alphabetQuizIndex,
                    onSelectAlphabet = { viewModel.selectAlphabet(it) },
                    onNextAlphabet = { viewModel.nextAlphabet() },
                    onPrevAlphabet = { viewModel.prevAlphabet() },
                    onSpeakAlphabet = { viewModel.speakCurrentAlphabet() },
                    onToggleQuiz = { viewModel.toggleAlphabetQuiz(it) },
                    onAnswerQuiz = { viewModel.answerAlphabetQuiz(it) },
                    onBackClick = { viewModel.navigateTo(AppScreen.HOME) },
                    onHomeClick = { viewModel.navigateTo(AppScreen.HOME) }
                )
                AppScreen.HINDI -> HindiScreen(
                    currentIndex = hindiIndex,
                    starsCount = progress.stars,
                    isQuizMode = isHindiQuizMode,
                    quizIndex = hindiQuizIndex,
                    onSelectHindiLetter = { viewModel.selectHindiLetter(it) },
                    onNextHindiLetter = { viewModel.nextHindiLetter() },
                    onPrevHindiLetter = { viewModel.prevHindiLetter() },
                    onSpeakHindiLetter = { viewModel.speakCurrentHindiLetter() },
                    onToggleQuiz = { viewModel.toggleHindiQuiz(it) },
                    onAnswerQuiz = { viewModel.answerHindiQuiz(it) },
                    onBackClick = { viewModel.navigateTo(AppScreen.HOME) },
                    onHomeClick = { viewModel.navigateTo(AppScreen.HOME) }
                )
                AppScreen.GAMES -> GamesScreen(
                    selectedGame = selectedGame,
                    starsCount = progress.stars,
                    findScore = findAnswerScore,
                    findQuestionIndex = findAnswerQuestionIndex,
                    onAnswerFindGame = { viewModel.answerFindGame(it) },
                    countingTarget = countingTarget,
                    countingEmoji = countingEmoji,
                    countingOptions = countingOptions,
                    onAnswerCountingGame = { viewModel.answerCountingGame(it) },
                    selectedMatchLeft = selectedMatchLeft,
                    matchedPairIds = matchedPairIds,
                    onSelectMatchKey = { viewModel.selectMatchKey(it) },
                    onSelectMatchTarget = { viewModel.selectMatchTarget(it) },
                    hindiTargetIdx = hindiGameTargetIndex,
                    hindiOptions = hindiGameOptions,
                    onAnswerHindiGame = { viewModel.answerHindiGame(it) },
                    memoryCards = memoryCards,
                    onFlipMemoryCard = { viewModel.flipMemoryCard(it) },
                    onSelectGameTab = { viewModel.selectMiniGame(it) },
                    onBackClick = { viewModel.navigateTo(AppScreen.HOME) },
                    onHomeClick = { viewModel.navigateTo(AppScreen.HOME) }
                )
                AppScreen.TROPHIES -> TrophyScreen(
                    progress = progress,
                    selectedTier = selectedTrophyTier,
                    currentQuestionIndex = trophyQuestionIndex,
                    currentScore = trophyScore,
                    celebrationTier = trophyCelebrationTier,
                    onStartChallenge = { viewModel.startTrophyChallenge(it) },
                    onAnswerQuestion = { viewModel.answerTrophyQuestion(it) },
                    onDismissCelebration = { viewModel.dismissTrophyCelebration() },
                    onBackClick = { viewModel.navigateTo(AppScreen.HOME) },
                    onHomeClick = { viewModel.navigateTo(AppScreen.HOME) }
                )
                AppScreen.REWARDS -> RewardsScreen(
                    progress = progress,
                    onBackClick = { viewModel.navigateTo(AppScreen.HOME) },
                    onHomeClick = { viewModel.navigateTo(AppScreen.HOME) }
                )
                AppScreen.PARENT_DASHBOARD -> ParentDashboardScreen(
                    progress = progress,
                    onResetProgress = { viewModel.resetAllProgress() },
                    onBackClick = { viewModel.navigateTo(AppScreen.SETTINGS) },
                    onHomeClick = { viewModel.navigateTo(AppScreen.HOME) }
                )
                AppScreen.SETTINGS -> SettingsScreen(
                    progress = progress,
                    onToggleSound = { viewModel.toggleSoundEffects(it) },
                    onToggleVoice = { viewModel.toggleVoice(it) },
                    onToggleMusic = { viewModel.toggleMusic(it) },
                    onSelectLanguage = { viewModel.setLanguage(it) },
                    onOpenParentGate = { viewModel.generateParentGateQuestion() },
                    onBackClick = { viewModel.navigateTo(AppScreen.HOME) },
                    onHomeClick = { viewModel.navigateTo(AppScreen.HOME) }
                )
            }
        }

        // Particle Confetti Burst Overlay
        ParticleConfetti(trigger = confettiTrigger)

        // Floating Cheerful Feedback Toast
        AnimatedVisibility(
            visible = feedbackToast != null,
            enter = fadeIn() + slideInVertically(initialOffsetY = { -it }),
            exit = fadeOut() + slideOutVertically(targetOffsetY = { -it }),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(top = 16.dp)
        ) {
            feedbackToast?.let { msg ->
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = KidsIndigo,
                    shadowElevation = 8.dp,
                    modifier = Modifier.padding(horizontal = 24.dp)
                ) {
                    Text(
                        text = msg,
                        style = MaterialTheme.typography.titleMedium,
                        color = KidsYellow,
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp)
                    )
                }
            }
        }

        // Parent Gate Dialog
        ParentGateDialog(
            isOpen = isParentGateOpen,
            question = parentGateQuestion,
            onDismiss = { viewModel.closeParentGate() },
            onVerify = { answer ->
                viewModel.verifyParentGateAnswer(answer)
            }
        )
    }
}
