package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.components.KidsButton
import com.example.ui.components.TopNavBar
import com.example.ui.theme.*
import com.example.viewmodel.MiniGameType

@Composable
fun GamesScreen(
    selectedGame: MiniGameType,
    starsCount: Int,
    // Game 1
    findScore: Int,
    findQuestionIndex: Int,
    onAnswerFindGame: (QuizOption) -> Unit,
    // Game 2
    countingTarget: Int,
    countingEmoji: String,
    countingOptions: List<Int>,
    onAnswerCountingGame: (Int) -> Unit,
    // Game 3
    selectedMatchLeft: String?,
    matchedPairIds: Set<String>,
    onSelectMatchKey: (String) -> Unit,
    onSelectMatchTarget: (MatchPairItem) -> Unit,
    // Game 4
    hindiTargetIdx: Int,
    hindiOptions: List<String>,
    onAnswerHindiGame: (String) -> Unit,
    // Game 5
    memoryCards: List<MemoryCard>,
    onFlipMemoryCard: (Int) -> Unit,
    onSelectGameTab: (MiniGameType) -> Unit,
    onBackClick: () -> Unit,
    onHomeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFFE8F5E9),
                        KidsBackgroundLight,
                        Color(0xFFEDE7F6)
                    )
                )
            )
            .systemBarsPadding()
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Navigation Bar
            TopNavBar(
                title = "Educational Games 🎮",
                starsCount = starsCount,
                onBackClick = onBackClick,
                onHomeClick = onHomeClick
            )

            // Game Selection Tabs Row
            ScrollableTabRow(
                selectedTabIndex = selectedGame.ordinal,
                edgePadding = 12.dp,
                containerColor = Color.Transparent,
                divider = {},
                indicator = {}
            ) {
                MiniGameType.values().forEach { gameType ->
                    val isSelected = gameType == selectedGame
                    val tabTitle = when (gameType) {
                        MiniGameType.FIND_ANSWER -> "1. Find It 🔤"
                        MiniGameType.NUMBER_COUNTING -> "2. Count 🍎"
                        MiniGameType.MATCH_PAIR -> "3. Match 🔗"
                        MiniGameType.HINDI_LETTER -> "4. Hindi 🇮🇳"
                        MiniGameType.MEMORY_CARDS -> "5. Memory 🎴"
                    }
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = if (isSelected) KidsIndigo else Color.White,
                        shadowElevation = if (isSelected) 4.dp else 1.dp,
                        modifier = Modifier
                            .padding(horizontal = 4.dp, vertical = 6.dp)
                            .clickable { onSelectGameTab(gameType) }
                            .testTag("game_tab_${gameType.name}")
                    ) {
                        Text(
                            text = tabTitle,
                            color = if (isSelected) Color.White else KidsTextDark,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Game Content Area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                when (selectedGame) {
                    MiniGameType.FIND_ANSWER -> GameFindAnswer(
                        questionIndex = findQuestionIndex,
                        score = findScore,
                        onAnswer = onAnswerFindGame
                    )
                    MiniGameType.NUMBER_COUNTING -> GameCounting(
                        target = countingTarget,
                        emoji = countingEmoji,
                        options = countingOptions,
                        onAnswer = onAnswerCountingGame
                    )
                    MiniGameType.MATCH_PAIR -> GameMatchPair(
                        selectedLeft = selectedMatchLeft,
                        matchedIds = matchedPairIds,
                        onSelectLeft = onSelectMatchKey,
                        onSelectTarget = onSelectMatchTarget
                    )
                    MiniGameType.HINDI_LETTER -> GameHindiLetter(
                        targetIndex = hindiTargetIdx,
                        options = hindiOptions,
                        onAnswer = onAnswerHindiGame
                    )
                    MiniGameType.MEMORY_CARDS -> GameMemoryCards(
                        cards = memoryCards,
                        onCardFlip = onFlipMemoryCard
                    )
                }
            }
        }
    }
}

@Composable
fun GameFindAnswer(
    questionIndex: Int,
    score: Int,
    onAnswer: (QuizOption) -> Unit
) {
    val question = KidsLearningData.ALPHABET_QUIZZES.getOrElse(questionIndex) { KidsLearningData.ALPHABET_QUIZZES[0] }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = Color.White,
            shadowElevation = 6.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(shape = RoundedCornerShape(12.dp), color = KidsBlue.copy(alpha = 0.2f)) {
                        Text(
                            text = "Game 1: Find Correct Answer",
                            color = KidsBlue,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                    Text(text = "Score: $score pts", fontWeight = FontWeight.Black, color = KidsIndigo)
                }

                Text(
                    text = question.subtitle,
                    style = MaterialTheme.typography.titleLarge,
                    color = KidsTextDark,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center
                )

                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .clip(CircleShape)
                        .background(KidsYellow.copy(alpha = 0.3f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = question.itemVisual, fontSize = 38.sp)
                }
            }
        }

        // Options
        question.options.forEach { opt ->
            KidsButton(
                text = "${opt.emoji}  ${opt.text}",
                onClick = { onAnswer(opt) },
                gradientColors = listOf(KidsIndigo, Color(0xFF3949AB)),
                height = 62.dp,
                fontSize = 19.sp,
                modifier = Modifier.fillMaxWidth(),
                testTag = "game_find_${opt.id}"
            )
        }
    }
}

@Composable
fun GameCounting(
    target: Int,
    emoji: String,
    options: List<Int>,
    onAnswer: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = Color.White,
            shadowElevation = 6.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Surface(shape = RoundedCornerShape(12.dp), color = KidsGreen.copy(alpha = 0.2f)) {
                    Text(
                        text = "Game 2: Number Counting",
                        color = KidsGreen,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }

                Text(
                    text = "How many items do you see?",
                    style = MaterialTheme.typography.titleLarge,
                    color = KidsTextDark,
                    fontWeight = FontWeight.Black
                )

                // Render counted items
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = KidsBackgroundLight,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(18.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        repeat(target) {
                            Text(
                                text = emoji,
                                fontSize = 36.sp,
                                modifier = Modifier.padding(horizontal = 4.dp)
                            )
                        }
                    }
                }
            }
        }

        // 3 Options
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val colors = listOf(
                listOf(KidsOrange, Color(0xFFF57C00)),
                listOf(KidsIndigo, Color(0xFF303F9F)),
                listOf(KidsPink, Color(0xFFC2185B))
            )
            options.forEachIndexed { index, num ->
                val gradient = colors.getOrElse(index) { colors[0] }
                KidsButton(
                    text = "$num",
                    onClick = { onAnswer(num) },
                    gradientColors = gradient,
                    height = 70.dp,
                    fontSize = 28.sp,
                    modifier = Modifier.weight(1f),
                    testTag = "game_count_opt_$num"
                )
            }
        }
    }
}

@Composable
fun GameMatchPair(
    selectedLeft: String?,
    matchedIds: Set<String>,
    onSelectLeft: (String) -> Unit,
    onSelectTarget: (MatchPairItem) -> Unit
) {
    val displayPairs = KidsLearningData.MATCH_PAIRS.take(4)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.White,
            shadowElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Game 3: Match the Pair",
                    style = MaterialTheme.typography.titleMedium,
                    color = KidsIndigo,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "Tap a Letter on the left, then tap its matching Picture!",
                    style = MaterialTheme.typography.bodyMedium,
                    color = KidsTextSecondary,
                    textAlign = TextAlign.Center
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Left Column (Keys: A, B, C, etc.)
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                displayPairs.forEach { pair ->
                    val isMatched = matchedIds.contains(pair.id)
                    val isSelected = selectedLeft == pair.keyText

                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = when {
                            isMatched -> Color(0xFFC8E6C9)
                            isSelected -> KidsYellow
                            else -> Color.White
                        },
                        shadowElevation = if (isSelected) 6.dp else 2.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                            .clickable(enabled = !isMatched) { onSelectLeft(pair.keyText) }
                            .testTag("match_left_${pair.keyText}")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = if (isMatched) "✓ ${pair.keyText}" else pair.keyText,
                                style = MaterialTheme.typography.titleLarge,
                                color = if (isMatched) Color(0xFF2E7D32) else KidsTextDark,
                                fontWeight = FontWeight.Black,
                                fontSize = 24.sp
                            )
                        }
                    }
                }
            }

            // Right Column (Targets: 🍎 Apple, ⚽ Ball, etc.)
            Column(
                modifier = Modifier.weight(1.3f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Shuffle display order for fun matching challenge
                val shuffledTargets = remember { displayPairs.shuffled() }

                shuffledTargets.forEach { pair ->
                    val isMatched = matchedIds.contains(pair.id)

                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = if (isMatched) Color(0xFFC8E6C9) else Color.White,
                        shadowElevation = 2.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                            .clickable(enabled = !isMatched) { onSelectTarget(pair) }
                            .testTag("match_target_${pair.targetText}")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(text = pair.targetEmoji, fontSize = 28.sp)
                            Text(
                                text = if (isMatched) "✓ ${pair.targetText}" else pair.targetText,
                                style = MaterialTheme.typography.titleMedium,
                                color = if (isMatched) Color(0xFF2E7D32) else KidsTextDark,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GameHindiLetter(
    targetIndex: Int,
    options: List<String>,
    onAnswer: (String) -> Unit
) {
    val targetItem = KidsLearningData.HINDI_VARNAMALA.getOrElse(targetIndex) { KidsLearningData.HINDI_VARNAMALA[0] }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = Color.White,
            shadowElevation = 6.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(shape = RoundedCornerShape(12.dp), color = KidsAmber.copy(alpha = 0.2f)) {
                    Text(
                        text = "Game 4: Hindi Letter Game",
                        color = KidsOrange,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }

                Text(
                    text = "इस अक्षर को पहचानिए:",
                    style = MaterialTheme.typography.titleLarge,
                    color = KidsTextDark,
                    fontWeight = FontWeight.Black
                )

                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .clip(CircleShape)
                        .background(KidsYellow),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = targetItem.letter,
                        fontSize = 52.sp,
                        color = Color(0xFF4E342E),
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }

        // 3 Options
        options.forEach { letter ->
            KidsButton(
                text = letter,
                onClick = { onAnswer(letter) },
                gradientColors = listOf(KidsAmber, KidsOrange),
                height = 62.dp,
                fontSize = 28.sp,
                modifier = Modifier.fillMaxWidth(),
                testTag = "game_hindi_opt_$letter"
            )
        }
    }
}

@Composable
fun GameMemoryCards(
    cards: List<MemoryCard>,
    onCardFlip: (Int) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color.White,
            shadowElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Game 5: Memory Match 🎴",
                    style = MaterialTheme.typography.titleMedium,
                    color = KidsIndigo,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "Flip cards & match pairs!",
                    style = MaterialTheme.typography.bodyMedium,
                    color = KidsTextSecondary,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // 4x2 Grid of Cards
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            itemsIndexed(cards) { index, card ->
                MemoryCardItem(
                    card = card,
                    onClick = { onCardFlip(index) }
                )
            }
        }
    }
}

@Composable
fun MemoryCardItem(
    card: MemoryCard,
    onClick: () -> Unit
) {
    val isRevealed = card.isFlipped || card.isMatched

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = when {
            card.isMatched -> Color(0xFFC8E6C9)
            isRevealed -> Color.White
            else -> KidsIndigo
        },
        shadowElevation = if (isRevealed) 2.dp else 4.dp,
        modifier = Modifier
            .aspectRatio(0.85f)
            .clip(RoundedCornerShape(16.dp))
            .clickable(enabled = !isRevealed, onClick = onClick)
            .testTag("memory_card_${card.id}")
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            if (isRevealed) {
                Text(
                    text = card.displayContent,
                    fontSize = if (card.isEmoji) 36.sp else 28.sp,
                    fontWeight = FontWeight.Black,
                    color = if (card.isMatched) Color(0xFF2E7D32) else KidsTextDark
                )
            } else {
                Text(
                    text = "❓",
                    fontSize = 26.sp
                )
            }
        }
    }
}
