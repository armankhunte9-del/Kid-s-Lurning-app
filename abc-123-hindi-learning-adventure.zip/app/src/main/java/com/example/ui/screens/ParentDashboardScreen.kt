package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.UserProgress
import com.example.ui.components.TopNavBar
import com.example.ui.theme.*

@Composable
fun ParentDashboardScreen(
    progress: UserProgress,
    onResetProgress: () -> Unit,
    onBackClick: () -> Unit,
    onHomeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showResetDialog by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFFE8EAF6),
                        KidsBackgroundLight,
                        Color(0xFFEDE7F6)
                    )
                )
            )
            .systemBarsPadding()
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            TopNavBar(
                title = "Parent Dashboard 👨‍👩‍👧",
                starsCount = progress.stars,
                onBackClick = onBackClick,
                onHomeClick = onHomeClick
            )

            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Welcome Banner
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = Color.White,
                    shadowElevation = 4.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "Learning Activity & Progress",
                            style = MaterialTheme.typography.titleLarge,
                            color = KidsIndigo,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "Here you can monitor your child's learning metrics, star rewards, and curriculum completion.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = KidsTextSecondary
                        )
                    }
                }

                // Summary Stats Grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MetricBox(
                        title = "Stars Earned",
                        value = "${progress.stars} ⭐",
                        color = KidsYellow,
                        modifier = Modifier.weight(1f)
                    )
                    MetricBox(
                        title = "Lessons Done",
                        value = "${progress.lessonsCompleted} 📚",
                        color = KidsSkyBlue,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MetricBox(
                        title = "Games Played",
                        value = "${progress.gamesPlayed} 🎮",
                        color = KidsGreen,
                        modifier = Modifier.weight(1f)
                    )
                    MetricBox(
                        title = "Trophies Won",
                        value = "${listOf(progress.hasBronzeTrophy, progress.hasSilverTrophy, progress.hasGoldTrophy).count { it }}/3 🏆",
                        color = KidsPink,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Curriculum Progress Bars
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = Color.White,
                    shadowElevation = 4.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "Curriculum Completion",
                            style = MaterialTheme.typography.titleMedium,
                            color = KidsTextDark,
                            fontWeight = FontWeight.Black
                        )

                        ProgressBarRow(label = "Numbers (1–100)", progress = (progress.lessonsCompleted * 0.1f).coerceIn(0.15f, 1f), color = KidsOrange)
                        ProgressBarRow(label = "English Alphabet (A–Z)", progress = (progress.lessonsCompleted * 0.12f).coerceIn(0.20f, 1f), color = KidsBlue)
                        ProgressBarRow(label = "हिंदी वर्णमाला (अ–ज्ञ)", progress = (progress.lessonsCompleted * 0.08f).coerceIn(0.10f, 1f), color = KidsAmber)
                        ProgressBarRow(label = "Educational Mini-Games", progress = (progress.gamesPlayed * 0.15f).coerceIn(0.25f, 1f), color = KidsGreen)
                    }
                }

                // Child Safety Info Card
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = Color.White,
                    shadowElevation = 4.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(text = "🛡️", fontSize = 24.sp)
                            Text(
                                text = "100% Child-Safe Environment",
                                style = MaterialTheme.typography.titleMedium,
                                color = KidsIndigo,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Text(
                            text = "• No third-party advertisements\n• No in-app external links or chat\n• All learning data stored securely on your device\n• Offline compatible",
                            style = MaterialTheme.typography.bodyMedium,
                            color = KidsTextSecondary,
                            lineHeight = 20.sp
                        )
                    }
                }

                // Reset Progress Action
                OutlinedButton(
                    onClick = { showResetDialog = true },
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = KidsRed),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    Text(
                        text = "Reset All Child Progress 🔄",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
        }

        // Reset Confirmation Dialog
        if (showResetDialog) {
            AlertDialog(
                onDismissRequest = { showResetDialog = false },
                title = { Text("Reset Progress?", fontWeight = FontWeight.Bold) },
                text = { Text("Are you sure you want to reset all earned stars and unlocked trophies? This action cannot be undone.") },
                confirmButton = {
                    Button(
                        onClick = {
                            showResetDialog = false
                            onResetProgress()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = KidsRed)
                    ) {
                        Text("Yes, Reset")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showResetDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

@Composable
fun MetricBox(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = Color.White,
        shadowElevation = 3.dp,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.headlineMedium,
                color = KidsTextDark,
                fontWeight = FontWeight.Black
            )
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                color = KidsTextSecondary,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun ProgressBarRow(
    label: String,
    progress: Float,
    color: Color
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = KidsTextDark)
            Text(text = "${(progress * 100).toInt()}%", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = color)
        }
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)),
            color = color,
            trackColor = Color(0xFFEEEEEE)
        )
    }
}
