package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.KidsLearningData
import com.example.data.NumberItem
import com.example.data.QuizOption
import com.example.data.QuizQuestion
import com.example.ui.components.KidsButton
import com.example.ui.components.TopNavBar
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun NumbersScreen(
    currentIndex: Int,
    starsCount: Int,
    isQuizMode: Boolean,
    quizIndex: Int,
    onSelectNumber: (Int) -> Unit,
    onNextNumber: () -> Unit,
    onPrevNumber: () -> Unit,
    onSpeakNumber: () -> Unit,
    onToggleQuiz: (Boolean) -> Unit,
    onAnswerQuiz: (QuizOption) -> Unit,
    onBackClick: () -> Unit,
    onHomeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val currentNumberItem = KidsLearningData.NUMBERS.getOrElse(currentIndex) { KidsLearningData.NUMBERS[0] }

    LaunchedEffect(currentIndex) {
        coroutineScope.launch {
            listState.animateScrollToItem((currentIndex - 2).coerceAtLeast(0))
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFFFFEDE1),
                        KidsBackgroundLight,
                        Color(0xFFE3F2FD)
                    )
                )
            )
            .systemBarsPadding()
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Navigation Bar
            TopNavBar(
                title = if (isQuizMode) "Number Quiz 🧩" else "Learn Numbers 1–100",
                starsCount = starsCount,
                onBackClick = {
                    if (isQuizMode) onToggleQuiz(false) else onBackClick()
                },
                onHomeClick = onHomeClick
            )

            if (isQuizMode) {
                // Quiz Mode View
                val currentQuiz = KidsLearningData.NUMBER_QUIZZES.getOrElse(quizIndex) { KidsLearningData.NUMBER_QUIZZES[0] }
                NumberQuizView(
                    question = currentQuiz,
                    quizIndex = quizIndex,
                    totalQuestions = KidsLearningData.NUMBER_QUIZZES.size,
                    onOptionSelected = onAnswerQuiz,
                    onExitQuiz = { onToggleQuiz(false) },
                    modifier = Modifier.weight(1f)
                )
            } else {
                // Standard Learning View
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Quick Horizontal Number Strip (1..100)
                    LazyRow(
                        state = listState,
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp)
                    ) {
                        itemsIndexed(KidsLearningData.NUMBERS) { index, item ->
                            val isSelected = index == currentIndex
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (isSelected) item.color else Color.White,
                                shadowElevation = if (isSelected) 6.dp else 2.dp,
                                modifier = Modifier
                                    .size(54.dp)
                                    .clickable { onSelectNumber(index) }
                                    .testTag("number_strip_${item.number}")
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "${item.number}",
                                        color = if (isSelected) Color.White else KidsTextDark,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 18.sp
                                    )
                                }
                            }
                        }
                    }

                    // Main Big Interactive Number Card
                    BigNumberDisplayCard(
                        item = currentNumberItem,
                        onSpeak = onSpeakNumber
                    )

                    // Previous / Voice / Next Controls Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        KidsButton(
                            text = "◀ PREV",
                            onClick = onPrevNumber,
                            gradientColors = listOf(KidsIndigo, Color(0xFF3F51B5)),
                            height = 56.dp,
                            fontSize = 16.sp,
                            modifier = Modifier.weight(1f)
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        // Big Voice Speak Button
                        Surface(
                            shape = CircleShape,
                            color = KidsPink,
                            shadowElevation = 8.dp,
                            modifier = Modifier
                                .size(64.dp)
                                .clickable(onClick = onSpeakNumber)
                                .testTag("speak_number_btn")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.VolumeUp,
                                    contentDescription = "Speak Number",
                                    tint = Color.White,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        KidsButton(
                            text = "NEXT ▶",
                            onClick = onNextNumber,
                            gradientColors = listOf(KidsGreen, Color(0xFF388E3C)),
                            height = 56.dp,
                            fontSize = 16.sp,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Practice Mode / Mini Quiz Launcher Banner
                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        color = KidsYellow,
                        shadowElevation = 4.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onToggleQuiz(true) }
                            .testTag("start_number_quiz_btn")
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(text = "🎯", fontSize = 32.sp)
                                Column {
                                    Text(
                                        text = "Play Number Mini Quiz!",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = Color(0xFF4E342E),
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = "Count objects & earn +10 Stars ⭐",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color(0xFF6D4C41),
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Text(text = "PLAY 🚀", fontWeight = FontWeight.Black, color = KidsIndigo)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BigNumberDisplayCard(
    item: NumberItem,
    onSpeak: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "numAnim")
    val bounce by infiniteTransition.animateFloat(
        initialValue = -4f,
        targetValue = 4f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "numBounce"
    )

    Surface(
        shape = RoundedCornerShape(32.dp),
        color = Color.White,
        shadowElevation = 8.dp,
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onSpeak)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header Pill: 1 — ONE — एक
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = item.color.copy(alpha = 0.2f)
            ) {
                Text(
                    text = "${item.number} — ${item.englishWord} — ${item.hindiWord}",
                    style = MaterialTheme.typography.titleMedium,
                    color = item.color,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }

            // Big Number Digit Display
            Box(
                modifier = Modifier
                    .size(130.dp)
                    .scale(1.0f)
                    .offset(y = bounce.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(item.color, item.color.copy(alpha = 0.7f))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "${item.number}",
                    fontSize = 64.sp,
                    color = Color.White,
                    fontWeight = FontWeight.Black
                )
            }

            // Counting Objects Grid (for visual learning up to 10 or sample visual)
            val displayCount = item.number.coerceAtMost(10)
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = KidsCardBg,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Counting: $displayCount ${item.englishWord.lowercase().replaceFirstChar { it.uppercase() }}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = KidsTextSecondary
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Emojis Row/Grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val count = if (item.number <= 10) item.number else 10
                        val row1 = count.coerceAtMost(5)
                        val row2 = (count - 5).coerceAtLeast(0)

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                repeat(row1) {
                                    Text(text = item.emoji, fontSize = 28.sp)
                                }
                            }
                            if (row2 > 0) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    repeat(row2) {
                                        Text(text = item.emoji, fontSize = 28.sp)
                                    }
                                }
                            }
                            if (item.number > 10) {
                                Text(
                                    text = "+ ${item.number - 10} more ${item.emoji}!",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = KidsOrange,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            Text(
                text = "Tap card or speaker to hear voice 🔊",
                style = MaterialTheme.typography.labelLarge,
                color = KidsTextSecondary,
                fontSize = 13.sp
            )
        }
    }
}

@Composable
fun NumberQuizView(
    question: QuizQuestion,
    quizIndex: Int,
    totalQuestions: Int,
    onOptionSelected: (QuizOption) -> Unit,
    onExitQuiz: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Quiz Card
        Surface(
            shape = RoundedCornerShape(32.dp),
            color = Color.White,
            shadowElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header Pill with Question Number
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = KidsIndigo.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = "Question ${quizIndex + 1} of $totalQuestions ⭐",
                            style = MaterialTheme.typography.titleMedium,
                            color = KidsIndigo,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }

                    Text(
                        text = "+10 Stars",
                        fontWeight = FontWeight.Black,
                        color = KidsOrange,
                        fontSize = 14.sp
                    )
                }

                LinearProgressIndicator(
                    progress = { (quizIndex + 1).toFloat() / totalQuestions.toFloat() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = KidsGreen,
                    trackColor = KidsBackgroundLight
                )

                Text(
                    text = question.subtitle,
                    style = MaterialTheme.typography.headlineMedium,
                    color = KidsTextDark,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                // Visual item (e.g. 🍎 🍎 🍎)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(KidsYellow.copy(alpha = 0.25f))
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = question.itemVisual,
                        fontSize = 38.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // 3 Answer Option Buttons
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val optionColors = listOf(
                listOf(KidsBlue, Color(0xFF1976D2)),
                listOf(KidsOrange, Color(0xFFF57C00)),
                listOf(KidsPurple, Color(0xFF7B1FA2))
            )

            question.options.forEachIndexed { idx, opt ->
                val gradient = optionColors.getOrElse(idx) { optionColors[0] }
                KidsButton(
                    text = "${opt.emoji}  ${opt.text}",
                    onClick = { onOptionSelected(opt) },
                    gradientColors = gradient,
                    height = 64.dp,
                    fontSize = 20.sp,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "quiz_opt_${opt.id}"
                )
            }
        }

        // Back to Learning Button
        TextButton(onClick = onExitQuiz) {
            Text(
                text = "Back to Number Explorer ↩",
                fontWeight = FontWeight.Bold,
                color = KidsIndigo,
                fontSize = 16.sp
            )
        }
    }
}
