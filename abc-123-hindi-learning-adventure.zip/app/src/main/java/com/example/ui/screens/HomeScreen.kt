package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.UserProgress
import com.example.ui.components.BottomBarTab
import com.example.ui.components.Playful3DCard
import com.example.ui.components.PlayfulBottomBar
import com.example.ui.theme.*

data class PlayfulHomeCardItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val emoji: String,
    val bg: Color,
    val shadow: Color,
    val subtitleColor: Color = Color.White.copy(alpha = 0.85f)
)

@Composable
fun HomeScreen(
    progress: UserProgress,
    onNavigateNumbers: () -> Unit,
    onNavigateAlphabet: () -> Unit,
    onNavigateHindi: () -> Unit,
    onNavigateGames: () -> Unit,
    onNavigateTrophies: () -> Unit,
    onNavigateRewards: () -> Unit,
    onNavigateSettings: () -> Unit,
    onNavigateParentDashboard: () -> Unit,
    onMascotSpeak: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    val cardItems = listOf(
        PlayfulHomeCardItem(
            id = "numbers",
            title = "Numbers",
            subtitle = "1 — 100",
            emoji = "🔢",
            bg = PlayfulOrange,
            shadow = PlayfulOrangeDark,
            subtitleColor = PlayfulOrangeLight
        ),
        PlayfulHomeCardItem(
            id = "alphabet",
            title = "ABCD",
            subtitle = "A — Z",
            emoji = "🔤",
            bg = PlayfulGreen,
            shadow = PlayfulGreenDark,
            subtitleColor = PlayfulGreenLight
        ),
        PlayfulHomeCardItem(
            id = "hindi",
            title = "हिंदी वर्णमाला",
            subtitle = "अ — ज्ञ",
            emoji = "🇮🇳",
            bg = PlayfulRed,
            shadow = PlayfulRedDark,
            subtitleColor = PlayfulRedLight
        ),
        PlayfulHomeCardItem(
            id = "games",
            title = "Games",
            subtitle = "5 Active",
            emoji = "🎮",
            bg = PlayfulPurple,
            shadow = PlayfulPurpleDark,
            subtitleColor = PlayfulPurpleLight
        ),
        PlayfulHomeCardItem(
            id = "trophies",
            title = "Trophy",
            subtitle = "Challenges",
            emoji = "🏆",
            bg = PlayfulYellow,
            shadow = PlayfulYellowDark,
            subtitleColor = Color(0xFF713F12)
        ),
        PlayfulHomeCardItem(
            id = "rewards",
            title = "Rewards",
            subtitle = "My Items",
            emoji = "💎",
            bg = PlayfulBlue,
            shadow = PlayfulBlueDark,
            subtitleColor = PlayfulBlueLight
        )
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(PlayfulCanvasBg)
            .statusBarsPadding()
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Header (h-16 white with rounded-b-[32px] and shadow)
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(
                        elevation = 6.dp,
                        shape = RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp),
                        spotColor = Color(0x14000000)
                    ),
                shape = RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp),
                color = Color.White
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left Brand: Yellow circular badge + App Title
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .shadow(2.dp, CircleShape)
                                .clip(CircleShape)
                                .background(PlayfulYellow)
                                .border(2.dp, Color.White, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "🏠", fontSize = 20.sp)
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "ABC 123 ",
                                style = MaterialTheme.typography.titleMedium,
                                color = PlayfulSlate800,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp,
                                letterSpacing = (-0.5).sp
                            )
                            Text(
                                text = "हिंदी",
                                style = MaterialTheme.typography.titleMedium,
                                color = PlayfulRed,
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp,
                                letterSpacing = (-0.5).sp
                            )
                        }
                    }

                    // Right Badge: Stars Counter
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = PlayfulSlate100,
                        modifier = Modifier.clickable(onClick = onNavigateRewards)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(text = "⭐", fontSize = 14.sp)
                            Text(
                                text = "${progress.stars}",
                                style = MaterialTheme.typography.labelLarge,
                                color = PlayfulSlate700,
                                fontWeight = FontWeight.Black,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }

            // Main Content Area
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(scrollState)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Avatars Row & "Next Challenge" glassmorphism pill
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Overlapping avatars: 👦 (blue), 👧 (pink), 🐻 (amber)
                    Row(
                        modifier = Modifier.padding(start = 4.dp)
                    ) {
                        // 1. Alex
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .shadow(2.dp, CircleShape)
                                .clip(CircleShape)
                                .background(Color(0xFFDBEAFE))
                                .border(2.dp, Color.White, CircleShape)
                                .clickable { onMascotSpeak("Alex says: Let's learn together! 🚀") },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "👦", fontSize = 24.sp)
                        }

                        // 2. Maya (-space-x-3 offset)
                        Box(
                            modifier = Modifier
                                .offset(x = (-12).dp)
                                .size(48.dp)
                                .shadow(2.dp, CircleShape)
                                .clip(CircleShape)
                                .background(Color(0xFFFCE7F3))
                                .border(2.dp, Color.White, CircleShape)
                                .clickable { onMascotSpeak("Maya says: You're doing amazing! ⭐") },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "👧", fontSize = 24.sp)
                        }

                        // 3. Barnaby (-space-x-3 offset)
                        Box(
                            modifier = Modifier
                                .offset(x = (-24).dp)
                                .size(48.dp)
                                .shadow(2.dp, CircleShape)
                                .clip(CircleShape)
                                .background(Color(0xFFFEF3C7))
                                .border(2.dp, Color.White, CircleShape)
                                .clickable { onMascotSpeak("Barnaby says: Yay! Let's play games! 🎮") },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "🐻", fontSize = 24.sp)
                        }
                    }

                    // Next Challenge Glassmorphism Card
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color.White.copy(alpha = 0.85f),
                        shadowElevation = 2.dp,
                        modifier = Modifier
                            .border(1.dp, Color.White, RoundedCornerShape(20.dp))
                            .clickable(onClick = onNavigateHindi)
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            horizontalAlignment = Alignment.End
                        ) {
                            Text(
                                text = "NEXT CHALLENGE",
                                style = MaterialTheme.typography.labelSmall,
                                color = PlayfulSlate600,
                                fontWeight = FontWeight.Black,
                                fontSize = 10.sp,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "Hindi Varnamala",
                                style = MaterialTheme.typography.labelLarge,
                                color = PlayfulBlue,
                                fontWeight = FontWeight.Black,
                                fontSize = 14.sp
                            )
                        }
                    }
                }

                // 2-Column Chunky 3D Action Cards Grid
                cardItems.chunked(2).forEach { rowCards ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        rowCards.forEach { card ->
                            Playful3DCard(
                                title = card.title,
                                subtitle = card.subtitle,
                                emoji = card.emoji,
                                backgroundColor = card.bg,
                                shadowColor = card.shadow,
                                subtitleColor = card.subtitleColor,
                                onClick = {
                                    when (card.id) {
                                        "numbers" -> onNavigateNumbers()
                                        "alphabet" -> onNavigateAlphabet()
                                        "hindi" -> onNavigateHindi()
                                        "games" -> onNavigateGames()
                                        "trophies" -> onNavigateTrophies()
                                        "rewards" -> onNavigateRewards()
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
            }

            // Footer (h-20 white with rounded-t-[40px] and shadow)
            PlayfulBottomBar(
                currentTab = BottomBarTab.HOME,
                onSelectTab = { tab ->
                    when (tab) {
                        BottomBarTab.HOME -> { /* already on home */ }
                        BottomBarTab.PROGRESS -> onNavigateRewards()
                        BottomBarTab.PARENTS -> onNavigateParentDashboard()
                        BottomBarTab.SETTINGS -> onNavigateSettings()
                    }
                }
            )
        }
    }
}
