package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.KidsLearningData
import com.example.data.QuizOption
import com.example.data.TrophyChallenge
import com.example.data.UserProgress
import com.example.ui.components.KidsButton
import com.example.ui.components.TopNavBar
import com.example.ui.theme.*

@Composable
fun TrophyScreen(
    progress: UserProgress,
    selectedTier: String,
    currentQuestionIndex: Int,
    currentScore: Int,
    celebrationTier: String?,
    onStartChallenge: (String) -> Unit,
    onAnswerQuestion: (QuizOption) -> Unit,
    onDismissCelebration: () -> Unit,
    onBackClick: () -> Unit,
    onHomeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentChallenge = KidsLearningData.TROPHIES.firstOrNull { it.tier == selectedTier }
        ?: KidsLearningData.TROPHIES[0]

    var isQuizActive by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFFFFF9C4),
                        KidsBackgroundLight,
                        Color(0xFFFFECB3)
                    )
                )
            )
            .systemBarsPadding()
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Navigation Bar
            TopNavBar(
                title = if (isQuizActive) "${currentChallenge.title} 🏆" else "Trophy Challenge 🏆",
                starsCount = progress.stars,
                onBackClick = {
                    if (isQuizActive) isQuizActive = false else onBackClick()
                },
                onHomeClick = onHomeClick
            )

            if (isQuizActive) {
                // Active Trophy Quiz Challenge
                TrophyQuizRunner(
                    challenge = currentChallenge,
                    questionIndex = currentQuestionIndex,
                    score = currentScore,
                    onOptionSelected = onAnswerQuestion,
                    onExit = { isQuizActive = false },
                    modifier = Modifier.weight(1f)
                )
            } else {
                // Trophy Tier Selector & Status
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Header Card
                    Surface(
                        shape = RoundedCornerShape(28.dp),
                        color = Color.White,
                        shadowElevation = 6.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "🏆 Champion Cups 🏆",
                                style = MaterialTheme.typography.headlineMedium,
                                color = KidsIndigo,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "Answer challenge questions correctly to unlock sparkling trophies for your trophy room!",
                                style = MaterialTheme.typography.bodyMedium,
                                color = KidsTextSecondary,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    // Trophies List (Bronze, Silver, Gold)
                    KidsLearningData.TROPHIES.forEach { trophy ->
                        val isUnlocked = when (trophy.tier) {
                            "BRONZE" -> progress.hasBronzeTrophy
                            "SILVER" -> progress.hasSilverTrophy
                            "GOLD", "GOLDEN" -> progress.hasGoldTrophy
                            else -> false
                        }

                        TrophyCardItem(
                            trophy = trophy,
                            isUnlocked = isUnlocked,
                            onPlayChallenge = {
                                onStartChallenge(trophy.tier)
                                isQuizActive = true
                            }
                        )
                    }
                }
            }
        }

        // Celebration Dialog Overlay
        if (celebrationTier != null) {
            TrophyCelebrationDialog(
                tier = celebrationTier,
                onDismiss = onDismissCelebration,
                onGoHome = {
                    onDismissCelebration()
                    onHomeClick()
                }
            )
        }
    }
}

@Composable
fun TrophyCardItem(
    trophy: TrophyChallenge,
    isUnlocked: Boolean,
    onPlayChallenge: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(26.dp),
        color = Color.White,
        shadowElevation = 6.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(trophy.badgeColor.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = trophy.emoji, fontSize = 36.sp)
                    }

                    Column {
                        Text(
                            text = trophy.title,
                            style = MaterialTheme.typography.titleLarge,
                            color = KidsTextDark,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = trophy.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = KidsTextSecondary
                        )
                    }
                }

                if (isUnlocked) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = KidsGreen.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = "UNLOCKED 🏆",
                            color = KidsGreen,
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            KidsButton(
                text = if (isUnlocked) "PLAY AGAIN 🔄" else "START CHALLENGE 🚀",
                onClick = onPlayChallenge,
                gradientColors = if (isUnlocked) {
                    listOf(KidsGreen, Color(0xFF388E3C))
                } else {
                    listOf(trophy.badgeColor, trophy.badgeColor.copy(alpha = 0.8f))
                },
                height = 56.dp,
                fontSize = 17.sp,
                modifier = Modifier.fillMaxWidth(),
                testTag = "play_trophy_${trophy.tier}"
            )
        }
    }
}

@Composable
fun TrophyQuizRunner(
    challenge: TrophyChallenge,
    questionIndex: Int,
    score: Int,
    onOptionSelected: (QuizOption) -> Unit,
    onExit: () -> Unit,
    modifier: Modifier = Modifier
) {
    val question = challenge.questions.getOrElse(questionIndex) { challenge.questions[0] }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = Color.White,
            shadowElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Question ${questionIndex + 1} of ${challenge.questions.size}",
                        fontWeight = FontWeight.Bold,
                        color = KidsIndigo
                    )
                    Text(
                        text = "Score: $score",
                        fontWeight = FontWeight.Black,
                        color = KidsOrange
                    )
                }

                Text(
                    text = question.subtitle,
                    style = MaterialTheme.typography.titleLarge,
                    color = KidsTextDark,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center
                )

                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .clip(CircleShape)
                        .background(challenge.badgeColor.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = question.itemVisual, fontSize = 42.sp)
                }
            }
        }

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            question.options.forEach { opt ->
                KidsButton(
                    text = "${opt.emoji}  ${opt.text}",
                    onClick = { onOptionSelected(opt) },
                    gradientColors = listOf(challenge.badgeColor, challenge.badgeColor.copy(alpha = 0.85f)),
                    height = 62.dp,
                    fontSize = 19.sp,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "trophy_opt_${opt.id}"
                )
            }
        }

        TextButton(onClick = onExit) {
            Text("Exit Challenge ↩", fontWeight = FontWeight.Bold, color = KidsIndigo)
        }
    }
}

@Composable
fun TrophyCelebrationDialog(
    tier: String,
    onDismiss: () -> Unit,
    onGoHome: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "celebrateAnim")
    val trophyScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "trophyScale"
    )

    val trophy = when (tier) {
        "BRONZE" -> Triple("🥉", "Bronze Trophy", TrophyBronze)
        "SILVER" -> Triple("🥈", "Silver Trophy", TrophySilver)
        else -> Triple("🥇", "Golden Trophy", TrophyGold)
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(32.dp),
            color = Color.White,
            shadowElevation = 16.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(text = "🎉 ✨ 🎊", fontSize = 32.sp)

                Box(
                    modifier = Modifier
                        .scale(trophyScale)
                        .size(120.dp)
                        .clip(CircleShape)
                        .background(trophy.third.copy(alpha = 0.25f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = trophy.first, fontSize = 68.sp)
                }

                Text(
                    text = "CONGRATULATIONS!",
                    style = MaterialTheme.typography.headlineMedium,
                    color = KidsIndigo,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "You won the ${trophy.second}!\nYou are a true Learning Champion! ⭐",
                    style = MaterialTheme.typography.titleMedium,
                    color = KidsTextDark,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                KidsButton(
                    text = "CLAIM REWARD 🏆",
                    onClick = onDismiss,
                    gradientColors = listOf(trophy.third, KidsOrange),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedButton(
                    onClick = onGoHome,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    Text("Go to Home 🏠", fontWeight = FontWeight.Bold, color = KidsIndigo)
                }
            }
        }
    }
}
