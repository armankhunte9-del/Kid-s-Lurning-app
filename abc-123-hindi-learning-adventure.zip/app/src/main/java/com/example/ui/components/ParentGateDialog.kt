package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.*
import com.example.viewmodel.ParentGateQuestion

@Composable
fun ParentGateDialog(
    isOpen: Boolean,
    question: ParentGateQuestion,
    onDismiss: () -> Unit,
    onVerify: (String) -> Unit
) {
    if (!isOpen) return

    var answerText by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = Color.White,
            shadowElevation = 16.dp,
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(text = "🔒", fontSize = 44.sp)

                Text(
                    text = "Grown-Ups & Parents Only",
                    style = MaterialTheme.typography.titleLarge,
                    color = KidsTextDark,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "Please solve this quick math question to access the Parent Dashboard:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = KidsTextSecondary,
                    textAlign = TextAlign.Center
                )

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = KidsYellow.copy(alpha = 0.3f),
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    Text(
                        text = "${question.num1} + ${question.num2} = ?",
                        style = MaterialTheme.typography.headlineLarge,
                        color = KidsIndigo,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp)
                    )
                }

                OutlinedTextField(
                    value = answerText,
                    onValueChange = {
                        answerText = it
                        errorMessage = null
                    },
                    label = { Text("Enter Answer") },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            if (answerText.isNotBlank()) {
                                onVerify(answerText)
                            }
                        }
                    ),
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage != null) {
                    Text(
                        text = errorMessage ?: "",
                        color = KidsRed,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f).height(50.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("Cancel", color = KidsTextSecondary, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            if (answerText.isNotBlank()) {
                                val success = answerText.trim() == question.answer.toString()
                                if (!success) {
                                    errorMessage = "Incorrect answer, please try again!"
                                } else {
                                    onVerify(answerText)
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = KidsIndigo),
                        modifier = Modifier.weight(1f).height(50.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("Unlock", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
