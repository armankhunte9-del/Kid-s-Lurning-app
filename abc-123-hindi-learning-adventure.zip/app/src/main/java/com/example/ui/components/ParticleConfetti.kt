package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*
import kotlin.random.Random

data class Particle(
    val initialX: Float,
    val initialY: Float,
    val speedX: Float,
    val speedY: Float,
    val color: Color,
    val size: Float,
    val rotation: Float
)

@Composable
fun ParticleConfetti(
    trigger: Int,
    modifier: Modifier = Modifier
) {
    if (trigger <= 0) return

    val particles = remember(trigger) {
        val colors = listOf(KidsRed, KidsYellow, KidsOrange, KidsPink, KidsBlue, KidsGreen, KidsPurple, TrophyGold)
        List(60) {
            Particle(
                initialX = Random.nextFloat() * 1000f,
                initialY = -50f - Random.nextFloat() * 200f,
                speedX = (Random.nextFloat() - 0.5f) * 600f,
                speedY = 600f + Random.nextFloat() * 800f,
                color = colors.random(),
                size = 12f + Random.nextFloat() * 16f,
                rotation = Random.nextFloat() * 360f
            )
        }
    }

    val progress = remember(trigger) { Animatable(0f) }

    LaunchedEffect(trigger) {
        progress.snapTo(0f)
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 2200, easing = LinearEasing)
        )
    }

    if (progress.value < 1f) {
        Canvas(modifier = modifier.fillMaxSize()) {
            val t = progress.value
            particles.forEach { p ->
                val currentX = (p.initialX + p.speedX * t).mod(size.width)
                val currentY = p.initialY + p.speedY * t
                val alpha = (1f - t * 0.8f).coerceIn(0f, 1f)

                if (currentY < size.height + 50) {
                    drawRect(
                        color = p.color.copy(alpha = alpha),
                        topLeft = Offset(currentX, currentY),
                        size = Size(p.size, p.size * 0.7f)
                    )
                }
            }
        }
    }
}
