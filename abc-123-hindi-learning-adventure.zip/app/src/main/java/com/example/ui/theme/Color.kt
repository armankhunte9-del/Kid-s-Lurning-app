package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Vibrant Playful Adventure Palette
val PlayfulCanvasBg = Color(0xFFE0F7FA) // Design HTML cyan canvas
val PlayfulCanvasBgEnd = Color(0xFFB2EBF2)
val PlayfulSlate800 = Color(0xFF1E293B)
val PlayfulSlate700 = Color(0xFF334155)
val PlayfulSlate600 = Color(0xFF475569)
val PlayfulSlate500 = Color(0xFF64748B)
val PlayfulSlate100 = Color(0xFFF1F5F9)
val PlayfulSlate50 = Color(0xFFF8FAFC)

// Chunky 3D Action Colors (Primary + 3D Shadow Bevel)
val PlayfulOrange = Color(0xFFFB923C)
val PlayfulOrangeDark = Color(0xFFEA580C)
val PlayfulOrangeLight = Color(0xFFFFEDD5)

val PlayfulGreen = Color(0xFF22C55E)
val PlayfulGreenDark = Color(0xFF15803D)
val PlayfulGreenLight = Color(0xFFDCFCE7)

val PlayfulRed = Color(0xFFEF4444)
val PlayfulRedDark = Color(0xFFB91C1C)
val PlayfulRedLight = Color(0xFFFEE2E2)

val PlayfulPurple = Color(0xFFA855F7)
val PlayfulPurpleDark = Color(0xFF7E22CE)
val PlayfulPurpleLight = Color(0xFFF3E8FF)

val PlayfulYellow = Color(0xFFFACC15)
val PlayfulYellowDark = Color(0xFFCA8A04)
val PlayfulYellowLight = Color(0xFFFEF9C3)

val PlayfulBlue = Color(0xFF3B82F6)
val PlayfulBlueDark = Color(0xFF1D4ED8)
val PlayfulBlueLight = Color(0xFFDBEAFE)
val PlayfulSkyBlue = Color(0xFF38BDF8)

// Joyful Kids Learning Palette (Preserved for compatibility)
val KidsYellow = PlayfulYellow
val KidsAmber = Color(0xFFFFB300)
val KidsOrange = PlayfulOrange
val KidsRed = PlayfulRed
val KidsPink = Color(0xFFFF4081)
val KidsPurple = PlayfulPurple
val KidsDeepPurple = Color(0xFF7E57C2)
val KidsIndigo = Color(0xFF4F46E5)
val KidsBlue = PlayfulBlue
val KidsSkyBlue = Color(0xFF38BDF8)
val KidsTeal = Color(0xFF14B8A6)
val KidsGreen = PlayfulGreen
val KidsLime = Color(0xFF84CC16)

// Trophy & Achievement Colors
val TrophyGold = Color(0xFFFFD700)
val TrophyGoldDark = Color(0xFFD97706)
val TrophySilver = Color(0xFFCBD5E1)
val TrophySilverDark = Color(0xFF64748B)
val TrophyBronze = Color(0xFFFB923C)
val TrophyBronzeDark = Color(0xFFC2410C)
val StarYellow = Color(0xFFFACC15)

// Background & Neutral Colors
val KidsBackgroundLight = PlayfulCanvasBg
val KidsSurfaceLight = Color(0xFFFFFFFF)
val KidsCardBg = Color(0xFFFFFFFF)
val KidsTextDark = PlayfulSlate800
val KidsTextSecondary = PlayfulSlate500
val KidsBorderColor = Color(0xFFE2E8F0)
val KidsSoftShadow = Color(0x0D000000)


