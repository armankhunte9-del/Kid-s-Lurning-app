package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.AppScreen

enum class BottomBarTab {
    HOME,
    PROGRESS,
    PARENTS,
    SETTINGS
}

@Composable
fun PlayfulBottomBar(
    currentTab: BottomBarTab,
    onSelectTab: (BottomBarTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .shadow(
                elevation = 12.dp,
                shape = RoundedCornerShape(topStart = 40.dp, topEnd = 40.dp),
                spotColor = Color(0x1F000000)
            ),
        shape = RoundedCornerShape(topStart = 40.dp, topEnd = 40.dp),
        color = Color.White
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Tab 1: Home
            BottomNavItem(
                icon = "🏡",
                label = "HOME",
                isActive = currentTab == BottomBarTab.HOME,
                activeColor = PlayfulBlue,
                onClick = { onSelectTab(BottomBarTab.HOME) }
            )

            // Tab 2: Progress (Rewards / Stats)
            BottomNavItem(
                icon = "📈",
                label = "PROGRESS",
                isActive = currentTab == BottomBarTab.PROGRESS,
                activeColor = PlayfulGreen,
                onClick = { onSelectTab(BottomBarTab.PROGRESS) }
            )

            // Tab 3: Parents (Parent Dashboard)
            BottomNavItem(
                icon = "👨‍👩‍👧",
                label = "PARENTS",
                isActive = currentTab == BottomBarTab.PARENTS,
                activeColor = PlayfulPurple,
                onClick = { onSelectTab(BottomBarTab.PARENTS) }
            )

            // Tab 4: Settings
            BottomNavItem(
                icon = "⚙️",
                label = "SETTINGS",
                isActive = currentTab == BottomBarTab.SETTINGS,
                activeColor = PlayfulOrange,
                onClick = { onSelectTab(BottomBarTab.SETTINGS) }
            )
        }
    }
}

@Composable
private fun BottomNavItem(
    icon: String,
    label: String,
    isActive: Boolean,
    activeColor: Color,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }

    Column(
        modifier = Modifier
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .padding(horizontal = 8.dp, vertical = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        if (isActive) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .shadow(4.dp, RoundedCornerShape(18.dp), spotColor = activeColor)
                    .clip(RoundedCornerShape(18.dp))
                    .background(activeColor),
                contentAlignment = Alignment.Center
            ) {
                Text(text = icon, fontSize = 24.sp)
            }
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Black,
                color = activeColor,
                letterSpacing = 0.5.sp
            )
        } else {
            Box(
                modifier = Modifier
                    .size(40.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = icon,
                    fontSize = 24.sp,
                    modifier = Modifier.alphaIf(!isActive)
                )
            }
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = PlayfulSlate500,
                letterSpacing = 0.5.sp
            )
        }
    }
}

private fun Modifier.alphaIf(condition: Boolean): Modifier =
    if (condition) this.alpha(0.55f) else this
