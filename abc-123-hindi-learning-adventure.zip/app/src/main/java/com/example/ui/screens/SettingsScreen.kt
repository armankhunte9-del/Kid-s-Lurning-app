package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.UserProgress
import com.example.ui.components.KidsButton
import com.example.ui.components.TopNavBar
import com.example.ui.theme.*

@Composable
fun SettingsScreen(
    progress: UserProgress,
    onToggleSound: (Boolean) -> Unit,
    onToggleVoice: (Boolean) -> Unit,
    onToggleMusic: (Boolean) -> Unit,
    onSelectLanguage: (String) -> Unit,
    onOpenParentGate: () -> Unit,
    onBackClick: () -> Unit,
    onHomeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFFE1F5FE),
                        KidsBackgroundLight,
                        Color(0xFFFFF3E0)
                    )
                )
            )
            .systemBarsPadding()
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            TopNavBar(
                title = "Settings ⚙️",
                starsCount = progress.stars,
                onBackClick = onBackClick,
                onHomeClick = onHomeClick
            )

            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Audio & Speech Settings Card
                Surface(
                    shape = RoundedCornerShape(26.dp),
                    color = Color.White,
                    shadowElevation = 5.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "🔊 Sound & Voice Settings",
                            style = MaterialTheme.typography.titleMedium,
                            color = KidsIndigo,
                            fontWeight = FontWeight.Black
                        )

                        SettingToggleRow(
                            emoji = "🔔",
                            title = "Sound Effects",
                            subtitle = "Fun pop chimes & star sparkle sounds",
                            isChecked = progress.soundEffectsEnabled,
                            onCheckedChange = onToggleSound
                        )

                        SettingToggleRow(
                            emoji = "🗣️",
                            title = "Voice Pronunciation",
                            subtitle = "Spoken numbers, letters and Hindi words",
                            isChecked = progress.voiceEnabled,
                            onCheckedChange = onToggleVoice
                        )

                        SettingToggleRow(
                            emoji = "🎵",
                            title = "Background Music",
                            subtitle = "Cheerful kid melodies and tones",
                            isChecked = progress.musicEnabled,
                            onCheckedChange = onToggleMusic
                        )
                    }
                }

                // Language Mode Settings Card
                Surface(
                    shape = RoundedCornerShape(26.dp),
                    color = Color.White,
                    shadowElevation = 5.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "🌐 Voice Language Mode",
                            style = MaterialTheme.typography.titleMedium,
                            color = KidsOrange,
                            fontWeight = FontWeight.Black
                        )

                        val languages = listOf(
                            Triple("BILINGUAL", "Bilingual (Hindi + English) 🇮🇳 🇺🇸", "Learn in both English and Hindi"),
                            Triple("ENGLISH", "English Only 🇺🇸", "English pronunciation"),
                            Triple("HINDI", "Hindi Only 🇮🇳", "हिंदी उच्चारण")
                        )

                        languages.forEach { (code, title, desc) ->
                            val isSelected = progress.selectedLanguage == code
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (isSelected) KidsYellow.copy(alpha = 0.35f) else Color(0xFFF7F7F7),
                                onClick = { onSelectLanguage(code) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(text = title, fontWeight = FontWeight.Bold, color = KidsTextDark)
                                        Text(text = desc, style = MaterialTheme.typography.bodyMedium, color = KidsTextSecondary, fontSize = 12.sp)
                                    }
                                    if (isSelected) {
                                        Text(text = "✓", color = KidsIndigo, fontWeight = FontWeight.Black, fontSize = 20.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                // Parent Dashboard Button (Protected with Math Gate)
                KidsButton(
                    text = "🔒 Parent Dashboard",
                    onClick = onOpenParentGate,
                    gradientColors = listOf(KidsIndigo, Color(0xFF3F51B5)),
                    height = 58.dp,
                    fontSize = 18.sp,
                    modifier = Modifier.fillMaxWidth()
                )

                // App Info & Child Safety
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color.White.copy(alpha = 0.8f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "ABC 123 हिंदी Learning Adventure",
                            style = MaterialTheme.typography.titleMedium,
                            color = KidsIndigo,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Version 1.0.0 • Designed for Kids 3–7 Years",
                            style = MaterialTheme.typography.bodyMedium,
                            color = KidsTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SettingToggleRow(
    emoji: String,
    title: String,
    subtitle: String,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            Text(text = emoji, fontSize = 26.sp)
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = KidsTextDark,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = KidsTextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = KidsGreen,
                uncheckedThumbColor = Color.White,
                uncheckedTrackColor = Color.LightGray
            )
        )
    }
}
