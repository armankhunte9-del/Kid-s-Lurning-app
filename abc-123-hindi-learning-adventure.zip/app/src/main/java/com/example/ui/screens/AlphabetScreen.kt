package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AlphabetItem
import com.example.data.KidsLearningData
import com.example.data.QuizOption
import com.example.data.QuizQuestion
import com.example.ui.components.KidsButton
import com.example.ui.components.TopNavBar
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun AlphabetScreen(
    currentIndex: Int,
    starsCount: Int,
    isQuizMode: Boolean,
    quizIndex: Int,
    onSelectAlphabet: (Int) -> Unit,
    onNextAlphabet: () -> Unit,
    onPrevAlphabet: () -> Unit,
    onSpeakAlphabet: () -> Unit,
    onToggleQuiz: (Boolean) -> Unit,
    onAnswerQuiz: (QuizOption) -> Unit,
    onBackClick: () -> Unit,
    onHomeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val currentLetterItem = KidsLearningData.ALPHABETS.getOrElse(currentIndex) { KidsLearningData.ALPHABETS[0] }

    LaunchedEffect(currentIndex) {
        coroutineScope.launch {
            listState.animateScrollToItem((currentIndex - 2).coerceAtLeast(0))
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFFE3F2FD),
                        KidsBackgroundLight,
                        Color(0xFFF3E5F5)
                    )
                )
            )
            .systemBarsPadding()
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Navigation Bar
            TopNavBar(
                title = if (isQuizMode) "Letter Quiz 🔤" else "English Alphabet A–Z",
                starsCount = starsCount,
                onBackClick = {
                    if (isQuizMode) onToggleQuiz(false) else onBackClick()
                },
                onHomeClick = onHomeClick
            )

            if (isQuizMode) {
                val currentQuiz = KidsLearningData.ALPHABET_QUIZZES.getOrElse(quizIndex) { KidsLearningData.ALPHABET_QUIZZES[0] }
                AlphabetQuizView(
                    question = currentQuiz,
                    quizIndex = quizIndex,
                    totalQuestions = KidsLearningData.ALPHABET_QUIZZES.size,
                    onOptionSelected = onAnswerQuiz,
                    onExitQuiz = { onToggleQuiz(false) },
                    modifier = Modifier.weight(1f)
                )
            } else {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Quick A-Z Horizontal Letter Strip
                    LazyRow(
                        state = listState,
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp)
                    ) {
                        itemsIndexed(KidsLearningData.ALPHABETS) { index, item ->
                            val isSelected = index == currentIndex
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (isSelected) item.color else Color.White,
                                shadowElevation = if (isSelected) 6.dp else 2.dp,
                                modifier = Modifier
                                    .size(54.dp)
                                    .clickable { onSelectAlphabet(index) }
                                    .testTag("alphabet_strip_${item.letter}")
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "${item.letter}",
                                        color = if (isSelected) Color.White else KidsTextDark,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 22.sp
                                    )
                                }
                            }
                        }
                    }

                    // Main Big Alphabet Card
                    BigAlphabetCard(
                        item = currentLetterItem,
                        onSpeak = onSpeakAlphabet
                    )

                    // Controls: Prev / Replay Voice / Next
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        KidsButton(
                            text = "◀ PREV",
                            onClick = onPrevAlphabet,
                            gradientColors = listOf(KidsIndigo, Color(0xFF3F51B5)),
                            height = 56.dp,
                            fontSize = 16.sp,
                            modifier = Modifier.weight(1f)
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        // Replay Voice Button
                        Surface(
                            shape = CircleShape,
                            color = KidsOrange,
                            shadowElevation = 8.dp,
                            modifier = Modifier
                                .size(64.dp)
                                .clickable(onClick = onSpeakAlphabet)
                                .testTag("replay_alphabet_voice_btn")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.VolumeUp,
                                    contentDescription = "Speak Letter",
                                    tint = Color.White,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        KidsButton(
                            text = "NEXT ▶",
                            onClick = onNextAlphabet,
                            gradientColors = listOf(KidsGreen, Color(0xFF388E3C)),
                            height = 56.dp,
                            fontSize = 16.sp,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Letter Matching Quiz Banner
                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        color = KidsSkyBlue.copy(alpha = 0.35f),
                        shadowElevation = 3.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onToggleQuiz(true) }
                            .testTag("start_alphabet_quiz_btn")
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(text = "🔤", fontSize = 32.sp)
                                Column {
                                    Text(
                                        text = "Play Letter Matching Game!",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = KidsIndigo,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = "Match letters to pictures & win stars ⭐",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = KidsTextDark,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Text(text = "PLAY 🚀", fontWeight = FontWeight.Black, color = KidsPink)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BigAlphabetCard(
    item: AlphabetItem,
    onSpeak: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "letterAnim")
    val bounce by infiniteTransition.animateFloat(
        initialValue = -5f,
        targetValue = 5f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "letterBounce"
    )

    Surface(
        shape = RoundedCornerShape(32.dp),
        color = Color.White,
        shadowElevation = 8.dp,
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onSpeak)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Letter Header Tag: e.g. "A for Apple"
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = item.color.copy(alpha = 0.2f)
            ) {
                Text(
                    text = "${item.letter} for ${item.word}",
                    style = MaterialTheme.typography.titleMedium,
                    color = item.color,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)
                )
            }

            // Big Upper & Lowercase Letter Avatar
            Box(
                modifier = Modifier
                    .size(130.dp)
                    .offset(y = bounce.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(item.color, item.color.copy(alpha = 0.7f))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "${item.letter} ${item.letter.lowercaseChar()}",
                    fontSize = 46.sp,
                    color = Color.White,
                    fontWeight = FontWeight.Black
                )
            }

            // Cartoon Object Emoji & Phonics Card
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = KidsCardBg,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Text(text = item.emoji, fontSize = 54.sp)

                    Column(horizontalAlignment = Alignment.Start) {
                        Text(
                            text = item.word,
                            style = MaterialTheme.typography.headlineMedium,
                            color = KidsTextDark,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "उच्चारण: ${item.hindiPhonetic}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = KidsIndigo,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Text(
                text = "“${item.letter} for ${item.word}” • Tap to hear voice 🔊",
                style = MaterialTheme.typography.labelLarge,
                color = KidsTextSecondary,
                fontSize = 13.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun AlphabetQuizView(
    question: QuizQuestion,
    quizIndex: Int,
    totalQuestions: Int,
    onOptionSelected: (QuizOption) -> Unit,
    onExitQuiz: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Surface(
            shape = RoundedCornerShape(32.dp),
            color = Color.White,
            shadowElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header Pill with Question Count
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = KidsPurple.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = "Question ${quizIndex + 1} of $totalQuestions ⭐",
                            style = MaterialTheme.typography.titleMedium,
                            color = KidsPurple,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }

                    Text(
                        text = "+10 Stars",
                        fontWeight = FontWeight.Black,
                        color = KidsPink,
                        fontSize = 14.sp
                    )
                }

                LinearProgressIndicator(
                    progress = { (quizIndex + 1).toFloat() / totalQuestions.toFloat() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = KidsPurple,
                    trackColor = KidsBackgroundLight
                )

                Text(
                    text = question.subtitle,
                    style = MaterialTheme.typography.headlineMedium,
                    color = KidsTextDark,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(KidsPink.copy(alpha = 0.2f))
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = question.itemVisual,
                        fontSize = 40.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val optionColors = listOf(
                listOf(KidsIndigo, Color(0xFF3949AB)),
                listOf(KidsPink, Color(0xFFD81B60)),
                listOf(KidsTeal, Color(0xFF00897B))
            )

            question.options.forEachIndexed { idx, opt ->
                val gradient = optionColors.getOrElse(idx) { optionColors[0] }
                KidsButton(
                    text = "${opt.emoji}  ${opt.text}",
                    onClick = { onOptionSelected(opt) },
                    gradientColors = gradient,
                    height = 64.dp,
                    fontSize = 20.sp,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "alphabet_opt_${opt.id}"
                )
            }
        }

        TextButton(onClick = onExitQuiz) {
            Text(
                text = "Back to Alphabet Explorer ↩",
                fontWeight = FontWeight.Bold,
                color = KidsIndigo,
                fontSize = 16.sp
            )
        }
    }
}
