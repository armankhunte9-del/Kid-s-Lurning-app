package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun CuteMascotRow(
    onMascotClick: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.Bottom
    ) {
        SingleMascotCard(
            emoji = "👦",
            name = "Alex",
            subtitle = "Explorer",
            gradient = listOf(Color(0xFF42A5F5), Color(0xFF1E88E5)),
            initialOffset = 0f,
            onClick = { onMascotClick("Alex says: Let's learn and win trophies! 🚀") }
        )
        SingleMascotCard(
            emoji = "👧",
            name = "Maya",
            subtitle = "Star Scholar",
            gradient = listOf(Color(0xFFFF4081), Color(0xFFF50057)),
            initialOffset = 180f,
            onClick = { onMascotClick("Maya says: You are doing super amazing! ⭐") }
        )
        SingleMascotCard(
            emoji = "🐻",
            name = "Barnaby",
            subtitle = "Buddy Bear",
            gradient = listOf(Color(0xFFFFB300), Color(0xFFFF8F00)),
            initialOffset = 90f,
            onClick = { onMascotClick("Barnaby says: Yay! Let's play fun games! 🎮") }
        )
    }
}

@Composable
fun SingleMascotCard(
    emoji: String,
    name: String,
    subtitle: String,
    gradient: List<Color>,
    initialOffset: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "mascotAnim")
    val bounce by infiniteTransition.animateFloat(
        initialValue = -4f,
        targetValue = 6f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
            initialStartOffset = StartOffset(initialOffset.toInt())
        ),
        label = "mascotBounce"
    )

    val wave by infiniteTransition.animateFloat(
        initialValue = -5f,
        targetValue = 5f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse,
            initialStartOffset = StartOffset((initialOffset * 2).toInt())
        ),
        label = "mascotWave"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .offset(y = bounce.dp)
            .clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .shadow(8.dp, CircleShape, spotColor = gradient.first())
                .clip(CircleShape)
                .background(Brush.linearGradient(gradient)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = emoji,
                fontSize = 38.sp,
                modifier = Modifier.rotate(wave)
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color.White.copy(alpha = 0.9f),
            shadowElevation = 2.dp
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(
                    text = name,
                    style = MaterialTheme.typography.labelLarge,
                    color = KidsTextDark,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }
    }
}
