package com.example.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

/**
 * 3D Chunky Action Button with playful border-b-6 bottom depth.
 */
@Composable
fun PlayfulChunkyButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    emoji: String? = null,
    backgroundColor: Color = PlayfulOrange,
    shadowColor: Color = PlayfulOrangeDark,
    textColor: Color = Color.White,
    fontSize: TextUnit = 18.sp,
    height: Dp = 60.dp,
    bottomDepth: Dp = 6.dp,
    testTag: String = "playful_chunky_button"
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val currentDepth by animateDpAsState(
        targetValue = if (isPressed) 0.dp else bottomDepth,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 500f),
        label = "btnDepth"
    )
    val pressOffset by animateDpAsState(
        targetValue = if (isPressed) bottomDepth else 0.dp,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 500f),
        label = "btnOffset"
    )

    Box(
        modifier = modifier
            .height(height)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .testTag(testTag)
    ) {
        // Bottom Shadow Layer (the 3D bevel depth)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .offset(y = bottomDepth)
                .clip(RoundedCornerShape(26.dp))
                .background(shadowColor)
        )

        // Top Face Layer (moves down when pressed)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .offset(y = pressOffset)
                .clip(RoundedCornerShape(26.dp))
                .background(backgroundColor)
                .padding(horizontal = 20.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                if (!emoji.isNullOrEmpty()) {
                    Text(
                        text = emoji,
                        fontSize = (fontSize.value + 6).sp,
                        modifier = Modifier.padding(end = 8.dp)
                    )
                }
                Text(
                    text = text,
                    color = textColor,
                    fontSize = fontSize,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

/**
 * 3D Chunky Playful Card for Home Menu and Modules with tactile press effect.
 */
@Composable
fun Playful3DCard(
    title: String,
    subtitle: String,
    emoji: String,
    backgroundColor: Color,
    shadowColor: Color,
    subtitleColor: Color = Color.White.copy(alpha = 0.85f),
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = "playful_card"
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val bottomDepth = 6.dp

    val pressOffset by animateDpAsState(
        targetValue = if (isPressed) bottomDepth else 0.dp,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 500f),
        label = "cardOffset"
    )

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .testTag(testTag)
    ) {
        // Bottom 3D bevel base
        Box(
            modifier = Modifier
                .fillMaxSize()
                .offset(y = bottomDepth)
                .clip(RoundedCornerShape(32.dp))
                .background(shadowColor)
        )

        // Top Card Face
        Box(
            modifier = Modifier
                .fillMaxSize()
                .offset(y = pressOffset)
                .clip(RoundedCornerShape(32.dp))
                .background(backgroundColor)
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = emoji,
                    fontSize = 42.sp,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center,
                    lineHeight = 22.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    color = subtitleColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun KidsButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    emoji: String? = null,
    gradientColors: List<Color> = listOf(PlayfulOrange, PlayfulOrangeDark),
    textColor: Color = Color.White,
    fontSize: TextUnit = 19.sp,
    height: Dp = 60.dp,
    elevation: Dp = 6.dp,
    testTag: String = "kids_button"
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val bottomDepth = 5.dp

    val pressOffset by animateDpAsState(
        targetValue = if (isPressed) bottomDepth else 0.dp,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 500f),
        label = "btnOffset"
    )

    Box(
        modifier = modifier
            .height(height)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .testTag(testTag)
    ) {
        val shadowColor = gradientColors.lastOrNull() ?: PlayfulOrangeDark
        val mainColor = gradientColors.firstOrNull() ?: PlayfulOrange

        // 3D Bottom Bevel
        Box(
            modifier = Modifier
                .fillMaxSize()
                .offset(y = bottomDepth)
                .clip(RoundedCornerShape(26.dp))
                .background(shadowColor)
        )

        // Top Face
        Box(
            modifier = Modifier
                .fillMaxSize()
                .offset(y = pressOffset)
                .clip(RoundedCornerShape(26.dp))
                .background(mainColor)
                .padding(horizontal = 20.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                if (!emoji.isNullOrEmpty()) {
                    Text(
                        text = emoji,
                        fontSize = (fontSize.value + 6).sp,
                        modifier = Modifier.padding(end = 8.dp)
                    )
                }
                Text(
                    text = text,
                    color = textColor,
                    fontSize = fontSize,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun KidsIconButton(
    emojiOrIcon: String,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    backgroundColor: Color = Color.White,
    borderColor: Color = Color(0xFFE2E8F0),
    testTag: String = "kids_icon_button"
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.90f else 1.0f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 500f),
        label = "iconBtnScale"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .scale(scale)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .testTag(testTag)
    ) {
        Box(
            modifier = Modifier
                .size(68.dp)
                .shadow(4.dp, RoundedCornerShape(22.dp))
                .clip(RoundedCornerShape(22.dp))
                .background(backgroundColor)
                .padding(8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = emojiOrIcon,
                fontSize = 32.sp
            )
        }
        if (label.isNotEmpty()) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = KidsTextDark,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
        }
    }
}

