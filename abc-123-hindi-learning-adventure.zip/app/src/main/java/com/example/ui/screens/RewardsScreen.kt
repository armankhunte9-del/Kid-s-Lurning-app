package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.UserProgress
import com.example.ui.components.TopNavBar
import com.example.ui.theme.*

@Composable
fun RewardsScreen(
    progress: UserProgress,
    onBackClick: () -> Unit,
    onHomeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "starGleam")
    val starScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "starGleamScale"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFFFFF8E1),
                        KidsBackgroundLight,
                        Color(0xFFFFECB3)
                    )
                )
            )
            .systemBarsPadding()
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Navigation Bar
            TopNavBar(
                title = "My Rewards & Trophies ⭐",
                starsCount = progress.stars,
                onBackClick = onBackClick,
                onHomeClick = onHomeClick
            )

            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Giant Star Bank Card
                Surface(
                    shape = RoundedCornerShape(32.dp),
                    color = Color.White,
                    shadowElevation = 8.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .scale(starScale)
                                .size(110.dp)
                                .clip(CircleShape)
                                .background(Brush.radialGradient(listOf(KidsYellow, KidsOrange))),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "⭐", fontSize = 58.sp)
                        }

                        Text(
                            text = "${progress.stars}",
                            style = MaterialTheme.typography.displayMedium,
                            color = Color(0xFFE65100),
                            fontWeight = FontWeight.Black
                        )

                        Text(
                            text = "Total Stars Earned",
                            style = MaterialTheme.typography.titleMedium,
                            color = KidsTextDark,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Trophy Room Shelf Card
                Surface(
                    shape = RoundedCornerShape(28.dp),
                    color = Color.White,
                    shadowElevation = 6.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "🏆 Trophy Room Shelf 🏆",
                            style = MaterialTheme.typography.titleLarge,
                            color = KidsIndigo,
                            fontWeight = FontWeight.Black
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Bronze Trophy Item
                            TrophyRoomItem(
                                emoji = "🥉",
                                name = "Bronze",
                                isUnlocked = progress.hasBronzeTrophy,
                                color = TrophyBronze
                            )

                            // Silver Trophy Item
                            TrophyRoomItem(
                                emoji = "🥈",
                                name = "Silver",
                                isUnlocked = progress.hasSilverTrophy,
                                color = TrophySilver
                            )

                            // Gold Trophy Item
                            TrophyRoomItem(
                                emoji = "🥇",
                                name = "Golden",
                                isUnlocked = progress.hasGoldTrophy,
                                color = TrophyGold
                            )
                        }
                    }
                }

                // Achievement Badges Card
                Surface(
                    shape = RoundedCornerShape(28.dp),
                    color = Color.White,
                    shadowElevation = 6.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "🎖️ Learning Badges",
                            style = MaterialTheme.typography.titleMedium,
                            color = KidsIndigo,
                            fontWeight = FontWeight.Black
                        )

                        BadgeItemRow(
                            emoji = "⚡",
                            title = "Fast Learner",
                            description = "Completed 5+ learning lessons",
                            isUnlocked = progress.lessonsCompleted >= 5,
                            badgeColor = KidsOrange
                        )

                        BadgeItemRow(
                            emoji = "🧠",
                            title = "Master Mind",
                            description = "Scored 50+ points in educational mini games",
                            isUnlocked = progress.gamesPlayed >= 5,
                            badgeColor = KidsPurple
                        )

                        BadgeItemRow(
                            emoji = "🌟",
                            title = "Super Star Champion",
                            description = "Earned 100+ total stars across the app",
                            isUnlocked = progress.stars >= 100,
                            badgeColor = TrophyGold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TrophyRoomItem(
    emoji: String,
    name: String,
    isUnlocked: Boolean,
    color: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .shadow(if (isUnlocked) 6.dp else 1.dp, CircleShape)
                .clip(CircleShape)
                .background(if (isUnlocked) color.copy(alpha = 0.25f) else Color(0xFFEEEEEE)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = if (isUnlocked) emoji else "🔒",
                fontSize = 36.sp
            )
        }

        Text(
            text = name,
            style = MaterialTheme.typography.labelLarge,
            color = if (isUnlocked) KidsTextDark else Color.Gray,
            fontWeight = FontWeight.Bold
        )

        Surface(
            shape = RoundedCornerShape(10.dp),
            color = if (isUnlocked) KidsGreen.copy(alpha = 0.2f) else Color(0xFFEEEEEE)
        ) {
            Text(
                text = if (isUnlocked) "WON 🏆" else "LOCKED",
                color = if (isUnlocked) KidsGreen else Color.Gray,
                fontSize = 10.sp,
                fontWeight = FontWeight.Black,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
    }
}

@Composable
fun BadgeItemRow(
    emoji: String,
    title: String,
    description: String,
    isUnlocked: Boolean,
    badgeColor: Color
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = if (isUnlocked) badgeColor.copy(alpha = 0.12f) else Color(0xFFFAFAFA),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(if (isUnlocked) badgeColor.copy(alpha = 0.25f) else Color(0xFFE0E0E0)),
                contentAlignment = Alignment.Center
            ) {
                Text(text = if (isUnlocked) emoji else "🔒", fontSize = 24.sp)
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (isUnlocked) KidsTextDark else Color.Gray,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = KidsTextSecondary,
                    fontSize = 12.sp
                )
            }

            if (isUnlocked) {
                Text(text = "✓", color = KidsGreen, fontWeight = FontWeight.Black, fontSize = 20.sp)
            }
        }
    }
}
