package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.HindiLetterItem
import com.example.data.KidsLearningData
import com.example.data.QuizOption
import com.example.data.QuizQuestion
import com.example.ui.components.KidsButton
import com.example.ui.components.TopNavBar
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun HindiScreen(
    currentIndex: Int,
    starsCount: Int,
    isQuizMode: Boolean,
    quizIndex: Int,
    onSelectHindiLetter: (Int) -> Unit,
    onNextHindiLetter: () -> Unit,
    onPrevHindiLetter: () -> Unit,
    onSpeakHindiLetter: () -> Unit,
    onToggleQuiz: (Boolean) -> Unit,
    onAnswerQuiz: (QuizOption) -> Unit,
    onBackClick: () -> Unit,
    onHomeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val currentLetterItem = KidsLearningData.HINDI_VARNAMALA.getOrElse(currentIndex) { KidsLearningData.HINDI_VARNAMALA[0] }

    LaunchedEffect(currentIndex) {
        coroutineScope.launch {
            listState.animateScrollToItem((currentIndex - 2).coerceAtLeast(0))
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFFFFF8E1),
                        KidsBackgroundLight,
                        Color(0xFFFFECB3)
                    )
                )
            )
            .systemBarsPadding()
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Navigation Bar
            TopNavBar(
                title = if (isQuizMode) "हिंदी प्रश्नोत्तरी 🇮🇳" else "हिंदी वर्णमाला अ–ज्ञ",
                starsCount = starsCount,
                onBackClick = {
                    if (isQuizMode) onToggleQuiz(false) else onBackClick()
                },
                onHomeClick = onHomeClick
            )

            if (isQuizMode) {
                val currentQuiz = KidsLearningData.HINDI_QUIZZES.getOrElse(quizIndex) { KidsLearningData.HINDI_QUIZZES[0] }
                HindiQuizView(
                    question = currentQuiz,
                    quizIndex = quizIndex,
                    totalQuestions = KidsLearningData.HINDI_QUIZZES.size,
                    onOptionSelected = onAnswerQuiz,
                    onExitQuiz = { onToggleQuiz(false) },
                    modifier = Modifier.weight(1f)
                )
            } else {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Category Indicator & Strip
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = if (currentLetterItem.isSwar) KidsPink.copy(alpha = 0.2f) else KidsTeal.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = if (currentLetterItem.isSwar) "स्वर (Vowels)" else "व्यंजन (Consonants)",
                                color = if (currentLetterItem.isSwar) KidsPink else KidsTeal,
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }

                        Text(
                            text = "${currentIndex + 1} / ${KidsLearningData.HINDI_VARNAMALA.size}",
                            color = KidsTextSecondary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    // Hindi Letters Horizontal Strip
                    LazyRow(
                        state = listState,
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp)
                    ) {
                        itemsIndexed(KidsLearningData.HINDI_VARNAMALA) { index, item ->
                            val isSelected = index == currentIndex
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (isSelected) item.color else Color.White,
                                shadowElevation = if (isSelected) 6.dp else 2.dp,
                                modifier = Modifier
                                    .size(54.dp)
                                    .clickable { onSelectHindiLetter(index) }
                                    .testTag("hindi_strip_${item.letter}")
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = item.letter,
                                        color = if (isSelected) Color.White else KidsTextDark,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 22.sp
                                    )
                                }
                            }
                        }
                    }

                    // Main Big Hindi Letter Card
                    BigHindiCard(
                        item = currentLetterItem,
                        onSpeak = onSpeakHindiLetter
                    )

                    // Navigation Controls: Prev / Voice / Next
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        KidsButton(
                            text = "◀ पिछला",
                            onClick = onPrevHindiLetter,
                            gradientColors = listOf(KidsIndigo, Color(0xFF3F51B5)),
                            height = 56.dp,
                            fontSize = 16.sp,
                            modifier = Modifier.weight(1f)
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        // Voice Speaker
                        Surface(
                            shape = CircleShape,
                            color = KidsPink,
                            shadowElevation = 8.dp,
                            modifier = Modifier
                                .size(64.dp)
                                .clickable(onClick = onSpeakHindiLetter)
                                .testTag("speak_hindi_voice_btn")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.VolumeUp,
                                    contentDescription = "Speak Hindi Letter",
                                    tint = Color.White,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        KidsButton(
                            text = "अगला ▶",
                            onClick = onNextHindiLetter,
                            gradientColors = listOf(KidsGreen, Color(0xFF388E3C)),
                            height = 56.dp,
                            fontSize = 16.sp,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Hindi Practice Question Banner
                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        color = KidsAmber.copy(alpha = 0.35f),
                        shadowElevation = 3.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onToggleQuiz(true) }
                            .testTag("start_hindi_quiz_btn")
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(text = "🇮🇳", fontSize = 32.sp)
                                Column {
                                    Text(
                                        text = "हिंदी अभ्यास प्रश्नोत्तरी!",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = Color(0xFFE65100),
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = "प्रश्नों के उत्तर दें और सितारे जीतें ⭐",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = KidsTextDark,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Text(text = "खेलें 🚀", fontWeight = FontWeight.Black, color = KidsIndigo)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BigHindiCard(
    item: HindiLetterItem,
    onSpeak: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "hindiAnim")
    val bounce by infiniteTransition.animateFloat(
        initialValue = -5f,
        targetValue = 5f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "hindiBounce"
    )

    Surface(
        shape = RoundedCornerShape(32.dp),
        color = Color.White,
        shadowElevation = 8.dp,
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onSpeak)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Tag: e.g. "अ — अनार"
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = item.color.copy(alpha = 0.2f)
            ) {
                Text(
                    text = "${item.letter} — ${item.word} (${item.englishTranslit})",
                    style = MaterialTheme.typography.titleMedium,
                    color = item.color,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)
                )
            }

            // Big Hindi Letter Character Avatar
            Box(
                modifier = Modifier
                    .size(130.dp)
                    .offset(y = bounce.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(item.color, item.color.copy(alpha = 0.7f))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = item.letter,
                    fontSize = 58.sp,
                    color = Color.White,
                    fontWeight = FontWeight.Black
                )
            }

            // Picture / Word Card
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = KidsCardBg,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Text(text = item.emoji, fontSize = 54.sp)

                    Column(horizontalAlignment = Alignment.Start) {
                        Text(
                            text = item.word,
                            style = MaterialTheme.typography.headlineMedium,
                            color = KidsTextDark,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "${item.letter} से ${item.word}",
                            style = MaterialTheme.typography.bodyLarge,
                            color = KidsOrange,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Text(
                text = "“${item.letter} से ${item.word}” • आवाज़ सुनने के लिए टैप करें 🔊",
                style = MaterialTheme.typography.labelLarge,
                color = KidsTextSecondary,
                fontSize = 13.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun HindiQuizView(
    question: QuizQuestion,
    quizIndex: Int,
    totalQuestions: Int,
    onOptionSelected: (QuizOption) -> Unit,
    onExitQuiz: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Surface(
            shape = RoundedCornerShape(32.dp),
            color = Color.White,
            shadowElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header Pill with Question Count
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = KidsAmber.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = "प्रश्न ${quizIndex + 1} / $totalQuestions ⭐",
                            style = MaterialTheme.typography.titleMedium,
                            color = KidsOrange,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }

                    Text(
                        text = "+10 Stars",
                        fontWeight = FontWeight.Black,
                        color = KidsOrange,
                        fontSize = 14.sp
                    )
                }

                LinearProgressIndicator(
                    progress = { (quizIndex + 1).toFloat() / totalQuestions.toFloat() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = KidsOrange,
                    trackColor = KidsBackgroundLight
                )

                Text(
                    text = question.subtitle,
                    style = MaterialTheme.typography.headlineMedium,
                    color = KidsTextDark,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .clip(CircleShape)
                        .background(KidsYellow.copy(alpha = 0.3f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = question.itemVisual,
                        fontSize = 48.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val optionColors = listOf(
                listOf(KidsOrange, Color(0xFFE65100)),
                listOf(KidsTeal, Color(0xFF00796B)),
                listOf(KidsIndigo, Color(0xFF283593))
            )

            question.options.forEachIndexed { idx, opt ->
                val gradient = optionColors.getOrElse(idx) { optionColors[0] }
                KidsButton(
                    text = "${opt.emoji}  ${opt.text}",
                    onClick = { onOptionSelected(opt) },
                    gradientColors = gradient,
                    height = 64.dp,
                    fontSize = 20.sp,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "hindi_opt_${opt.id}"
                )
            }
        }

        TextButton(onClick = onExitQuiz) {
            Text(
                text = "Back to Hindi Varnamala ↩",
                fontWeight = FontWeight.Bold,
                color = KidsIndigo,
                fontSize = 16.sp
            )
        }
    }
}
