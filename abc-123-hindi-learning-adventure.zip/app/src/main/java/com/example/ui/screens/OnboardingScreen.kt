package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.KidsButton
import com.example.ui.theme.*

data class OnboardingPageData(
    val badge: String,
    val title: String,
    val subtitle: String,
    val description: String,
    val bgGradient: List<Color>,
    val characterEmoji: String
)

@Composable
fun OnboardingScreen(
    currentStep: Int,
    onNextStep: () -> Unit,
    onSkip: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pages = listOf(
        OnboardingPageData(
            badge = "🌈 Welcome!",
            title = "Welcome to ABC 123",
            subtitle = "हिंदी Learning Adventure!",
            description = "A magical world of interactive learning for kids aged 3–7 with cute cartoon characters and voice!",
            bgGradient = listOf(Color(0xFFE0F7FA), Color(0xFFFFF9E6)),
            characterEmoji = "👦 🐻 👧"
        ),
        OnboardingPageData(
            badge = "📚 Learn & Play",
            title = "Numbers, ABCD & Hindi",
            subtitle = "Fun & Interactive Lessons",
            description = "Learn Numbers 1–100, English Alphabet A–Z, and complete Hindi Varnamala अ–ज्ञ through exciting games!",
            bgGradient = listOf(Color(0xFFFFF3E0), Color(0xFFF3E5F5)),
            characterEmoji = "🔢 🔤 🇮🇳"
        ),
        OnboardingPageData(
            badge = "🏆 Win Trophies",
            title = "Trophy Challenge",
            subtitle = "Become a Super Champion!",
            description = "Earn Stars ⭐, unlock Bronze 🥉, Silver 🥈, and Golden 🥇 Trophies with colorful celebrations!",
            bgGradient = listOf(Color(0xFFEDE7F6), Color(0xFFE8F5E9)),
            characterEmoji = "🏆 🥇 ⭐"
        )
    )

    val page = pages.getOrElse(currentStep) { pages.last() }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(page.bgGradient))
            .systemBarsPadding()
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Indicator Row & Skip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Step Dots
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    pages.indices.forEach { index ->
                        Box(
                            modifier = Modifier
                                .size(if (index == currentStep) 24.dp else 10.dp, 10.dp)
                                .clip(RoundedCornerShape(5.dp))
                                .background(
                                    if (index == currentStep) KidsIndigo else Color.LightGray
                                )
                        )
                    }
                }

                if (currentStep < 2) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color.White.copy(alpha = 0.8f),
                        onClick = onSkip
                    ) {
                        Text(
                            text = "Skip",
                            color = KidsTextSecondary,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            // Main Content Card
            Surface(
                shape = RoundedCornerShape(32.dp),
                color = Color.White,
                shadowElevation = 8.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Badge
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = KidsYellow,
                        shadowElevation = 2.dp
                    ) {
                        Text(
                            text = page.badge,
                            style = MaterialTheme.typography.titleMedium,
                            color = Color(0xFF4E342E),
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                        )
                    }

                    // Cartoon Emoji Mascot Area
                    Box(
                        modifier = Modifier
                            .size(130.dp)
                            .shadow(6.dp, CircleShape)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(KidsSkyBlue, KidsPink)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = page.characterEmoji,
                            fontSize = 38.sp,
                            textAlign = TextAlign.Center
                        )
                    }

                    // Titles
                    Text(
                        text = page.title,
                        style = MaterialTheme.typography.headlineMedium,
                        color = KidsIndigo,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = page.subtitle,
                        style = MaterialTheme.typography.titleMedium,
                        color = KidsOrange,
                        fontWeight = FontWeight.ExtraBold,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = page.description,
                        style = MaterialTheme.typography.bodyLarge,
                        color = KidsTextSecondary,
                        textAlign = TextAlign.Center,
                        lineHeight = 22.sp
                    )
                }
            }

            // Bottom Action Button
            KidsButton(
                text = if (currentStep == 2) "START LEARNING 🚀" else "NEXT ➡️",
                onClick = onNextStep,
                modifier = Modifier.fillMaxWidth(),
                gradientColors = if (currentStep == 2) {
                    listOf(KidsGreen, Color(0xFF43A047))
                } else {
                    listOf(KidsOrange, KidsAmber)
                },
                height = 68.dp,
                fontSize = 22.sp,
                testTag = "onboarding_action_button"
            )
        }
    }
}
