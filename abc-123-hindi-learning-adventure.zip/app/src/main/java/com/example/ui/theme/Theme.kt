package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

/**
 * 'Vibrant Playful Adventure' Light Color Palette
 * Designed with high-energy cheerful primary colors, high-contrast readable text,
 * and soft sky-cyan background canvas for kids' exploration.
 */
val VibrantPlayfulAdventureLightColorScheme = lightColorScheme(
    primary = PlayfulBlue,
    onPrimary = Color.White,
    primaryContainer = PlayfulBlueLight,
    onPrimaryContainer = PlayfulBlueDark,
    secondary = PlayfulOrange,
    onSecondary = Color.White,
    secondaryContainer = PlayfulOrangeLight,
    onSecondaryContainer = PlayfulOrangeDark,
    tertiary = PlayfulPurple,
    onTertiary = Color.White,
    tertiaryContainer = PlayfulPurpleLight,
    onTertiaryContainer = PlayfulPurpleDark,
    background = PlayfulCanvasBg,
    onBackground = PlayfulSlate800,
    surface = KidsSurfaceLight,
    onSurface = PlayfulSlate800,
    surfaceVariant = PlayfulSlate100,
    onSurfaceVariant = PlayfulSlate600,
    outline = KidsBorderColor,
    error = PlayfulRed,
    onError = Color.White,
    errorContainer = PlayfulRedLight,
    onErrorContainer = PlayfulRedDark
)

/**
 * 'Vibrant Playful Adventure' Dark Color Palette
 * Eye-safe, high-contrast playful dark theme with glowing jewel tones for kids.
 */
val VibrantPlayfulAdventureDarkColorScheme = darkColorScheme(
    primary = PlayfulSkyBlue,
    onPrimary = Color(0xFF0F172A),
    primaryContainer = Color(0xFF1E3A8A),
    onPrimaryContainer = PlayfulBlueLight,
    secondary = PlayfulYellow,
    onSecondary = Color(0xFF451A03),
    secondaryContainer = Color(0xFF78350F),
    onSecondaryContainer = PlayfulYellowLight,
    tertiary = PlayfulPurpleLight,
    onTertiary = Color(0xFF3B0764),
    tertiaryContainer = Color(0xFF581C87),
    onTertiaryContainer = PlayfulPurpleLight,
    background = Color(0xFF0F172A),
    onBackground = Color(0xFFF8FAFC),
    surface = Color(0xFF1E293B),
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = Color(0xFF334155),
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = Color(0xFF475569),
    error = PlayfulRed,
    onError = Color.White
)

/**
 * Vibrant Playful Adventure Theme
 * Sets up cheerful primary colors, rounded children-friendly shapes, and bouncy typography.
 */
@Composable
fun VibrantPlayfulAdventureTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Set to false by default to preserve custom cheerful palette
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> VibrantPlayfulAdventureDarkColorScheme
        else -> VibrantPlayfulAdventureLightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = PlayfulShapes,
        content = content
    )
}

/**
 * Alias for project compatibility.
 */
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    VibrantPlayfulAdventureTheme(
        darkTheme = darkTheme,
        dynamicColor = dynamicColor,
        content = content
    )
}
