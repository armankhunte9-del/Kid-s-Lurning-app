package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.sin

class SoundManager(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isTtsReady = false
    private var toneGenerator: ToneGenerator? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val audioScope = CoroutineScope(Dispatchers.Default)

    var soundEffectsEnabled: Boolean = true
    var voiceEnabled: Boolean = true
    var musicEnabled: Boolean = true

    init {
        try {
            tts = TextToSpeech(context.applicationContext, this)
            toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 85)
        } catch (e: Exception) {
            Log.e("SoundManager", "Error initializing TTS/Audio: ${e.message}")
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            tts?.let { engine ->
                // Set child-friendly pitch and speech rate
                engine.setPitch(1.15f)
                engine.setSpeechRate(0.85f)
                // Default to English/Indian English or Hindi locale
                val langResult = engine.setLanguage(Locale.ENGLISH)
                if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                    engine.language = Locale.getDefault()
                }
            }
        }
    }

    fun speak(text: String, isHindi: Boolean = false) {
        if (!voiceEnabled || !isTtsReady || tts == null) return

        try {
            tts?.let { engine ->
                if (isHindi) {
                    val hindiLocale = Locale("hi", "IN")
                    val result = engine.setLanguage(hindiLocale)
                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        engine.language = Locale.getDefault()
                    }
                } else {
                    val result = engine.setLanguage(Locale.ENGLISH)
                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        engine.language = Locale.getDefault()
                    }
                }
                engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "KIDS_SPEECH_${System.currentTimeMillis()}")
            }
        } catch (e: Exception) {
            Log.e("SoundManager", "Speak failed: ${e.message}")
        }
    }

    fun speakNumber(number: Int, englishWord: String, hindiWord: String, selectedLang: String = "BILINGUAL") {
        when (selectedLang.uppercase()) {
            "ENGLISH" -> speak("$number. $englishWord.", isHindi = false)
            "HINDI" -> speak("$number. $hindiWord.", isHindi = true)
            else -> {
                // Bilingual: say number, english and hindi
                speak("$number. $englishWord. $hindiWord.", isHindi = false)
            }
        }
    }

    fun speakAlphabet(letter: Char, word: String) {
        speak("$letter for $word.", isHindi = false)
    }

    fun speakHindiLetter(letter: String, word: String) {
        speak("$letter से $word", isHindi = true)
    }

    fun playCorrectSound() {
        if (!soundEffectsEnabled) return
        audioScope.launch {
            playMelody(listOf(523.25, 659.25, 783.99, 1046.50), listOf(80, 80, 80, 180))
        }
    }

    fun playWrongSound() {
        if (!soundEffectsEnabled) return
        audioScope.launch {
            playMelody(listOf(349.23, 311.13, 277.18), listOf(120, 120, 200))
        }
    }

    fun playTapSound() {
        if (!soundEffectsEnabled) return
        audioScope.launch {
            playTone(880.0, 50)
        }
    }

    fun playStarSound() {
        if (!soundEffectsEnabled) return
        audioScope.launch {
            playMelody(listOf(783.99, 987.77, 1174.66, 1567.98), listOf(60, 60, 60, 150))
        }
    }

    fun playTrophyCelebration() {
        if (!soundEffectsEnabled) return
        audioScope.launch {
            // Fanfare victory chords
            val notes = listOf(
                523.25, 523.25, 523.25, 659.25, 783.99, 1046.50,
                783.99, 1046.50
            )
            val durations = listOf(100, 100, 100, 250, 250, 400, 150, 600)
            playMelody(notes, durations)
        }
    }

    private fun playTone(freq: Double, durationMs: Int) {
        try {
            val sampleRate = 22050
            val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
            val sample = ShortArray(numSamples)

            for (i in 0 until numSamples) {
                // Envelope for smooth click-free sound
                val envelope = when {
                    i < 200 -> i / 200.0
                    i > numSamples - 200 -> (numSamples - i) / 200.0
                    else -> 1.0
                }
                val angle = 2.0 * Math.PI * i / (sampleRate / freq)
                sample[i] = (sin(angle) * 32767 * 0.5 * envelope).toInt().toShort()
            }

            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(numSamples * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.write(sample, 0, numSamples)
            track.play()

            mainHandler.postDelayed({
                try {
                    track.stop()
                    track.release()
                } catch (e: Exception) {
                    // ignore
                }
            }, (durationMs + 100).toLong())
        } catch (e: Exception) {
            // Fallback to tone generator
            try {
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, durationMs)
            } catch (ignored: Exception) {}
        }
    }

    private fun playMelody(notes: List<Double>, durations: List<Int>) {
        for (i in notes.indices) {
            playTone(notes[i], durations[i])
            try {
                Thread.sleep(durations[i].toLong() + 20)
            } catch (e: InterruptedException) {
                break
            }
        }
    }

    fun release() {
        try {
            tts?.stop()
            tts?.shutdown()
            toneGenerator?.release()
        } catch (e: Exception) {
            // ignore
        }
    }
}
