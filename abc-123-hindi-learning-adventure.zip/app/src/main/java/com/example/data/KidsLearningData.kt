package com.example.data

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

data class NumberItem(
    val number: Int,
    val englishWord: String,
    val hindiWord: String,
    val emoji: String,
    val color: Color
)

data class AlphabetItem(
    val letter: Char,
    val word: String,
    val hindiPhonetic: String,
    val emoji: String,
    val color: Color
)

data class HindiLetterItem(
    val letter: String,
    val word: String,
    val englishTranslit: String,
    val emoji: String,
    val isSwar: Boolean,
    val color: Color
)

data class QuizOption(
    val id: String,
    val text: String,
    val emoji: String = "",
    val isCorrect: Boolean
)

data class QuizQuestion(
    val id: Int,
    val title: String,
    val subtitle: String,
    val itemVisual: String, // large emoji or display
    val options: List<QuizOption>,
    val correctMessage: String = "🎉 Great Job!",
    val explanation: String = ""
)

data class MatchPairItem(
    val id: String,
    val keyText: String, // e.g., "A"
    val targetText: String, // e.g., "Apple"
    val targetEmoji: String, // e.g., "🍎"
    val color: Color
)

data class MemoryCard(
    val id: Int,
    val pairId: Int,
    val displayContent: String,
    val isEmoji: Boolean,
    val title: String,
    var isFlipped: Boolean = false,
    var isMatched: Boolean = false,
    val color: Color
)

data class TrophyChallenge(
    val tier: String, // "BRONZE", "SILVER", "GOLDEN"
    val title: String,
    val description: String,
    val starsReward: Int,
    val celebrationMessage: String,
    val requiredScore: Int,
    val questions: List<QuizQuestion>
) {
    val emoji: String
        get() = when (tier) {
            "BRONZE" -> "🥉"
            "SILVER" -> "🥈"
            else -> "🥇"
        }

    val badgeColor: Color
        get() = when (tier) {
            "BRONZE" -> TrophyBronze
            "SILVER" -> TrophySilver
            else -> TrophyGold
        }
}

object KidsLearningData {

    // 1 to 100 Numbers data
    val NUMBERS: List<NumberItem> by lazy {
        val emojis = listOf("🍎", "⭐", "🎈", "🚗", "🍌", "🍓", "🐶", "🐱", "🍦", "🌸", "🦋", "⚽", "🍭", "🍇", "🦆", "🐟")
        val colors = listOf(KidsRed, KidsOrange, KidsAmber, KidsGreen, KidsTeal, KidsBlue, KidsIndigo, KidsPurple, KidsPink)

        val hindiNumberWords = mapOf(
            1 to "एक", 2 to "दो", 3 to "तीन", 4 to "चार", 5 to "पाँच",
            6 to "छह", 7 to "सात", 8 to "आठ", 9 to "नौ", 10 to "दस",
            11 to "ग्यारह", 12 to "बारह", 13 to "तेरह", 14 to "चौदह", 15 to "पंद्रह",
            16 to "सोलह", 17 to "सत्रह", 18 to "अठारह", 19 to "उन्नीस", 20 to "बीस",
            21 to "इक्कीस", 22 to "बाईस", 23 to "तेईस", 24 to "चौबीस", 25 to "पच्चीस",
            26 to "छब्बीस", 27 to "सत्ताईस", 28 to "अट्ठाईस", 29 to "उनतीस", 30 to "तीस",
            31 to "इकतीस", 32 to "बत्तीस", 33 to "तैंतीस", 34 to "चौंतीस", 35 to "पैंतीस",
            36 to "छत्तीस", 37 to "सैंतीस", 38 to "अड़तीस", 39 to "उनतालीस", 40 to "चालीस",
            41 to "इकतालीस", 42 to "बयालीस", 43 to "तैंतालीस", 44 to "चवालीस", 45 to "पैंतालीस",
            46 to "छियालीस", 47 to "सैंतालीस", 48 to "अड़तालीस", 49 to "उनचास", 50 to "पचास",
            55 to "पचपन", 60 to "साठ", 65 to "पैंसठ", 70 to "सत्तर", 75 to "पचहत्तर",
            80 to "अस्सी", 85 to "पचासी", 90 to "नब्बे", 95 to "पंचानवे", 100 to "सौ"
        )

        val englishNumberWords = mapOf(
            1 to "ONE", 2 to "TWO", 3 to "THREE", 4 to "FOUR", 5 to "FIVE",
            6 to "SIX", 7 to "SEVEN", 8 to "EIGHT", 9 to "NINE", 10 to "TEN",
            11 to "ELEVEN", 12 to "TWELVE", 13 to "THIRTEEN", 14 to "FOURTEEN", 15 to "FIFTEEN",
            16 to "SIXTEEN", 17 to "SEVENTEEN", 18 to "EIGHTEEN", 19 to "NINETEEN", 20 to "TWENTY",
            21 to "TWENTY-ONE", 22 to "TWENTY-TWO", 23 to "TWENTY-THREE", 24 to "TWENTY-FOUR", 25 to "TWENTY-FIVE",
            26 to "TWENTY-SIX", 27 to "TWENTY-SEVEN", 28 to "TWENTY-EIGHT", 29 to "TWENTY-NINE", 30 to "THIRTY",
            35 to "THIRTY-FIVE", 40 to "FORTY", 45 to "FORTY-FIVE", 50 to "FIFTY",
            55 to "FIFTY-FIVE", 60 to "SIXTY", 65 to "SIXTY-FIVE", 70 to "SEVENTY",
            75 to "SEVENTY-FIVE", 80 to "EIGHTY", 85 to "EIGHTY-FIVE", 90 to "NINETY",
            95 to "NINETY-FIVE", 100 to "ONE HUNDRED"
        )

        (1..100).map { num ->
            val eng = englishNumberWords[num] ?: run {
                val tens = (num / 10) * 10
                val units = num % 10
                val tensStr = englishNumberWords[tens] ?: "NUMBER"
                val unitsStr = englishNumberWords[units] ?: ""
                "$tensStr-$unitsStr"
            }
            val hin = hindiNumberWords[num] ?: "संख्या $num"
            val emoji = emojis[(num - 1) % emojis.size]
            val color = colors[(num - 1) % colors.size]
            NumberItem(num, eng, hin, emoji, color)
        }
    }

    // A to Z English Alphabet
    val ALPHABETS: List<AlphabetItem> = listOf(
        AlphabetItem('A', "Apple", "एप्पल", "🍎", KidsRed),
        AlphabetItem('B', "Ball", "बॉल", "⚽", KidsBlue),
        AlphabetItem('C', "Cat", "कैट", "🐱", KidsOrange),
        AlphabetItem('D', "Dog", "डॉग", "🐶", KidsAmber),
        AlphabetItem('E', "Elephant", "एलिफेंट", "🐘", KidsIndigo),
        AlphabetItem('F', "Fish", "फिश", "🐟", KidsTeal),
        AlphabetItem('G', "Grapes", "ग्रेप्स", "🍇", KidsPurple),
        AlphabetItem('H', "Horse", "हॉर्स", "🐴", KidsAmber),
        AlphabetItem('I', "Ice Cream", "आइसक्रीम", "🍦", KidsPink),
        AlphabetItem('J', "Juice", "जूस", "🧃", KidsOrange),
        AlphabetItem('K', "Kite", "काइट", "🪁", KidsDeepPurple),
        AlphabetItem('L', "Lion", "लायन", "🦁", KidsYellow),
        AlphabetItem('M', "Monkey", "मंकी", "🐵", KidsAmber),
        AlphabetItem('N', "Nest", "नेस्ट", "🪺", KidsGreen),
        AlphabetItem('O', "Orange", "ऑरेंज", "🍊", KidsOrange),
        AlphabetItem('P', "Penguin", "पेंगुइन", "🐧", KidsBlue),
        AlphabetItem('Q', "Queen", "क्वीन", "👑", KidsPurple),
        AlphabetItem('R', "Rainbow", "रेनबो", "🌈", KidsRed),
        AlphabetItem('S', "Sun", "सन", "☀️", KidsYellow),
        AlphabetItem('T', "Tiger", "टाइगर", "🐯", KidsOrange),
        AlphabetItem('U', "Umbrella", "अम्ब्रेला", "☂️", KidsDeepPurple),
        AlphabetItem('V', "Violin", "वायलिन", "🎻", KidsAmber),
        AlphabetItem('W', "Watch", "वॉच", "⌚", KidsTeal),
        AlphabetItem('X', "Xylophone", "ज़ाइलोफोन", "🎼", KidsPink),
        AlphabetItem('Y', "Yacht", "यॉट", "⛵", KidsBlue),
        AlphabetItem('Z', "Zebra", "ज़ेब्रा", "🦓", KidsIndigo)
    )

    // Complete Hindi Varnamala: Swar (अ-अः) and Vyanjan (क-ज्ञ)
    val HINDI_VARNAMALA: List<HindiLetterItem> = listOf(
        // Swar (स्वर)
        HindiLetterItem("अ", "अनार", "Anaar", "🍎", true, KidsRed),
        HindiLetterItem("आ", "आम", "Aam", "🥭", true, KidsYellow),
        HindiLetterItem("इ", "इमली", "Imli", "🌿", true, KidsGreen),
        HindiLetterItem("ई", "ईख", "Eekh", "🎋", true, KidsTeal),
        HindiLetterItem("उ", "उल्लू", "Ullu", "🦉", true, KidsIndigo),
        HindiLetterItem("ऊ", "ऊन", "Oon", "🧶", true, KidsPink),
        HindiLetterItem("ऋ", "ऋषि", "Rishi", "🧘", true, KidsOrange),
        HindiLetterItem("ए", "एड़ी", "Edee", "🦶", true, KidsAmber),
        HindiLetterItem("ऐ", "ऐनक", "Ainak", "👓", true, KidsBlue),
        HindiLetterItem("ओ", "ओखली", "Okhli", "🥣", true, KidsDeepPurple),
        HindiLetterItem("औ", "औरत", "Aurat", "👩", true, KidsPurple),
        HindiLetterItem("अं", "अंगूर", "Angoor", "🍇", true, KidsGreen),
        HindiLetterItem("अः", "खाली", "Khaali", "✨", true, KidsAmber),

        // Vyanjan (व्यंजन)
        HindiLetterItem("क", "कबूतर", "Kabootar", "🕊️", false, KidsSkyBlue),
        HindiLetterItem("ख", "खरगोश", "Khargosh", "🐰", false, KidsPink),
        HindiLetterItem("ग", "गमला", "Gamla", "🪴", false, KidsGreen),
        HindiLetterItem("घ", "घड़ी", "Ghadi", "⏰", false, KidsOrange),
        HindiLetterItem("ङ", "खाली", "Khaali", "🌟", false, KidsYellow),
        HindiLetterItem("च", "चम्मच", "Chammach", "🥄", false, KidsTeal),
        HindiLetterItem("छ", "छतरी", "Chhatri", "☂️", false, KidsPurple),
        HindiLetterItem("ज", "जहाज", "Jahaaz", "🚢", false, KidsBlue),
        HindiLetterItem("झ", "झंडा", "Jhanda", "🇮🇳", false, KidsRed),
        HindiLetterItem("ञ", "खाली", "Khaali", "💫", false, KidsAmber),
        HindiLetterItem("ट", "टमाटर", "Tamatar", "🍅", false, KidsRed),
        HindiLetterItem("ठ", "ठठेरा", "Thathela", "🔨", false, KidsAmber),
        HindiLetterItem("ड", "डमरू", "Damroo", "🪘", false, KidsDeepPurple),
        HindiLetterItem("ढ", "ढोलक", "Dholak", "🥁", false, KidsOrange),
        HindiLetterItem("ण", "खाली", "Khaali", "⭐", false, KidsGreen),
        HindiLetterItem("त", "तरबूज", "Tarbooz", "🍉", false, KidsGreen),
        HindiLetterItem("थ", "थर्मस", "Thermos", "🫖", false, KidsBlue),
        HindiLetterItem("द", "दवात", "Dawaat", "🖋️", false, KidsIndigo),
        HindiLetterItem("ध", "धनुष", "Dhanush", "🏹", false, KidsAmber),
        HindiLetterItem("न", "नल", "Nal", "🚰", false, KidsSkyBlue),
        HindiLetterItem("प", "पतंग", "Patang", "🪁", false, KidsPink),
        HindiLetterItem("फ", "फल", "Phal", "🍏", false, KidsGreen),
        HindiLetterItem("ब", "बत्तख", "Battakh", "🦆", false, KidsYellow),
        HindiLetterItem("भ", "भालू", "Bhaloo", "🐻", false, KidsOrange),
        HindiLetterItem("म", "मछली", "Machhli", "🐟", false, KidsTeal),
        HindiLetterItem("य", "यज्ञ", "Yagya", "🪔", false, KidsAmber),
        HindiLetterItem("र", "रथ", "Rath", "🎪", false, KidsRed),
        HindiLetterItem("ल", "लट्टू", "Lattoo", "🪀", false, KidsPurple),
        HindiLetterItem("व", "वक", "Vak", "🦢", false, KidsBlue),
        HindiLetterItem("श", "शंख", "Shankh", "🐚", false, KidsPink),
        HindiLetterItem("ष", "षट्कोण", "Shatkon", "⬡", false, KidsIndigo),
        HindiLetterItem("स", "सूरज", "Sooraj", "☀️", false, KidsYellow),
        HindiLetterItem("ह", "हाथी", "Haathi", "🐘", false, KidsTeal),
        HindiLetterItem("क्ष", "क्षत्रिय", "Kshatriya", "🛡️", false, KidsRed),
        HindiLetterItem("त्र", "त्रिशूल", "Trishool", "🔱", false, KidsAmber),
        HindiLetterItem("ज्ञ", "ज्ञानी", "Gyaani", "🧙‍♂️", false, KidsPurple)
    )

    // Match Pairs for Game 3
    val MATCH_PAIRS: List<MatchPairItem> = listOf(
        MatchPairItem("1", "A", "Apple", "🍎", KidsRed),
        MatchPairItem("2", "B", "Ball", "⚽", KidsBlue),
        MatchPairItem("3", "C", "Cat", "🐱", KidsOrange),
        MatchPairItem("4", "D", "Dog", "🐶", KidsAmber),
        MatchPairItem("5", "E", "Elephant", "🐘", KidsIndigo),
        MatchPairItem("6", "अ", "अनार", "🍎", KidsRed),
        MatchPairItem("7", "आ", "आम", "🥭", KidsYellow),
        MatchPairItem("8", "क", "कबूतर", "🕊️", KidsSkyBlue),
        MatchPairItem("9", "1", "One", "⭐", KidsYellow),
        MatchPairItem("10", "5", "Five", "🖐️", KidsPink)
    )

    // Mini Quiz for Numbers (10 Questions)
    val NUMBER_QUIZZES: List<QuizQuestion> = listOf(
        QuizQuestion(
            id = 101,
            title = "Counting Fun! 🍎",
            subtitle = "How many apples are there?",
            itemVisual = "🍎 🍎 🍎",
            options = listOf(
                QuizOption("1", "2 Apples", "2️⃣", false),
                QuizOption("2", "3 Apples", "3️⃣", true),
                QuizOption("3", "5 Apples", "5️⃣", false)
            )
        ),
        QuizQuestion(
            id = 102,
            title = "Star Counting! ⭐",
            subtitle = "How many stars are shining?",
            itemVisual = "⭐ ⭐ ⭐ ⭐ ⭐",
            options = listOf(
                QuizOption("1", "4 Stars", "4️⃣", false),
                QuizOption("2", "5 Stars", "5️⃣", true),
                QuizOption("3", "6 Stars", "6️⃣", false)
            )
        ),
        QuizQuestion(
            id = 103,
            title = "Balloon Fun! 🎈",
            subtitle = "Count the colorful balloons!",
            itemVisual = "🎈 🎈",
            options = listOf(
                QuizOption("1", "2 Balloons", "2️⃣", true),
                QuizOption("2", "1 Balloon", "1️⃣", false),
                QuizOption("3", "3 Balloons", "3️⃣", false)
            )
        ),
        QuizQuestion(
            id = 104,
            title = "Puppy Friends! 🐶",
            subtitle = "How many cute puppies?",
            itemVisual = "🐶 🐶 🐶 🐶",
            options = listOf(
                QuizOption("1", "3 Puppies", "3️⃣", false),
                QuizOption("2", "4 Puppies", "4️⃣", true),
                QuizOption("3", "7 Puppies", "7️⃣", false)
            )
        ),
        QuizQuestion(
            id = 105,
            title = "Yummy Ice Cream! 🍦",
            subtitle = "Count the delicious cones!",
            itemVisual = "🍦",
            options = listOf(
                QuizOption("1", "1 Ice Cream", "1️⃣", true),
                QuizOption("2", "2 Ice Creams", "2️⃣", false),
                QuizOption("3", "4 Ice Creams", "4️⃣", false)
            )
        ),
        QuizQuestion(
            id = 106,
            title = "Speedy Cars! 🚗",
            subtitle = "How many cars on the road?",
            itemVisual = "🚗 🚗 🚗 🚗 🚗 🚗",
            options = listOf(
                QuizOption("1", "5 Cars", "5️⃣", false),
                QuizOption("2", "6 Cars", "6️⃣", true),
                QuizOption("3", "8 Cars", "8️⃣", false)
            )
        ),
        QuizQuestion(
            id = 107,
            title = "Sweet Strawberries! 🍓",
            subtitle = "Count the juicy strawberries!",
            itemVisual = "🍓 🍓 🍓 🍓 🍓 🍓 🍓",
            options = listOf(
                QuizOption("1", "6 Strawberries", "6️⃣", false),
                QuizOption("2", "7 Strawberries", "7️⃣", true),
                QuizOption("3", "9 Strawberries", "9️⃣", false)
            )
        ),
        QuizQuestion(
            id = 108,
            title = "Little Fishies! 🐟",
            subtitle = "How many fish swimming in the water?",
            itemVisual = "🐟 🐟 🐟 🐟 🐟 🐟 🐟 🐟",
            options = listOf(
                QuizOption("1", "8 Fish", "8️⃣", true),
                QuizOption("2", "7 Fish", "7️⃣", false),
                QuizOption("3", "10 Fish", "🔟", false)
            )
        ),
        QuizQuestion(
            id = 109,
            title = "Pretty Flowers! 🌸",
            subtitle = "Count the blooming flowers!",
            itemVisual = "🌸 🌸 🌸 🌸 🌸 🌸 🌸 🌸 🌸",
            options = listOf(
                QuizOption("1", "8 Flowers", "8️⃣", false),
                QuizOption("2", "9 Flowers", "9️⃣", true),
                QuizOption("3", "10 Flowers", "🔟", false)
            )
        ),
        QuizQuestion(
            id = 110,
            title = "Ten Number Challenge! 🔟",
            subtitle = "How many soccer balls?",
            itemVisual = "⚽ ⚽ ⚽ ⚽ ⚽ ⚽ ⚽ ⚽ ⚽ ⚽",
            options = listOf(
                QuizOption("1", "9 Balls", "9️⃣", false),
                QuizOption("2", "10 Balls", "🔟", true),
                QuizOption("3", "12 Balls", "1️⃣2️⃣", false)
            )
        )
    )

    // Mini Quiz for Alphabet (10 Questions)
    val ALPHABET_QUIZZES: List<QuizQuestion> = listOf(
        QuizQuestion(
            id = 201,
            title = "Letter Challenge! 🔤",
            subtitle = "Which letter starts 'Apple' 🍎?",
            itemVisual = "🍎 Apple",
            options = listOf(
                QuizOption("1", "A", "🅰️", true),
                QuizOption("2", "B", "🅱️", false),
                QuizOption("3", "C", "©️", false)
            )
        ),
        QuizQuestion(
            id = 202,
            title = "Find the Letter ⚽",
            subtitle = "Which letter is for 'Ball'?",
            itemVisual = "⚽ Ball",
            options = listOf(
                QuizOption("1", "D", "🐶", false),
                QuizOption("2", "B", "⚽", true),
                QuizOption("3", "F", "🐟", false)
            )
        ),
        QuizQuestion(
            id = 203,
            title = "Cute Cat Sound 🐱",
            subtitle = "C is for...?",
            itemVisual = "🐱 Meow!",
            options = listOf(
                QuizOption("1", "Cat", "🐱", true),
                QuizOption("2", "Dog", "🐶", false),
                QuizOption("3", "Elephant", "🐘", false)
            )
        ),
        QuizQuestion(
            id = 204,
            title = "Jungle King 🦁",
            subtitle = "Which letter is for 'Lion'?",
            itemVisual = "🦁 Lion",
            options = listOf(
                QuizOption("1", "L", "🦁", true),
                QuizOption("2", "M", "🐵", false),
                QuizOption("3", "P", "🐧", false)
            )
        ),
        QuizQuestion(
            id = 205,
            title = "Big Animal 🐘",
            subtitle = "E is for which giant animal?",
            itemVisual = "🐘 Trrr!",
            options = listOf(
                QuizOption("1", "Elephant", "🐘", true),
                QuizOption("2", "Fish", "🐟", false),
                QuizOption("3", "Grapes", "🍇", false)
            )
        ),
        QuizQuestion(
            id = 206,
            title = "Flying High 🪁",
            subtitle = "Which letter starts 'Kite'?",
            itemVisual = "🪁 Kite",
            options = listOf(
                QuizOption("1", "J", "🧃", false),
                QuizOption("2", "K", "🪁", true),
                QuizOption("3", "L", "🦁", false)
            )
        ),
        QuizQuestion(
            id = 207,
            title = "Playful Monkey 🐵",
            subtitle = "M is for...?",
            itemVisual = "🐵 Ooh-aah!",
            options = listOf(
                QuizOption("1", "Nest", "🪺", false),
                QuizOption("2", "Monkey", "🐵", true),
                QuizOption("3", "Orange", "🍊", false)
            )
        ),
        QuizQuestion(
            id = 208,
            title = "Shining Sun ☀️",
            subtitle = "Which letter is for 'Sun'?",
            itemVisual = "☀️ Sun",
            options = listOf(
                QuizOption("1", "S", "☀️", true),
                QuizOption("2", "R", "🌈", false),
                QuizOption("3", "T", "🐯", false)
            )
        ),
        QuizQuestion(
            id = 209,
            title = "Rainy Day Helper ☂️",
            subtitle = "U is for...?",
            itemVisual = "☂️ Rainy Day",
            options = listOf(
                QuizOption("1", "Umbrella", "☂️", true),
                QuizOption("2", "Violin", "🎻", false),
                QuizOption("3", "Watch", "⌚", false)
            )
        ),
        QuizQuestion(
            id = 210,
            title = "Striped Friend 🦓",
            subtitle = "Z is for...?",
            itemVisual = "🦓 Striped Animal",
            options = listOf(
                QuizOption("1", "Zebra", "🦓", true),
                QuizOption("2", "Yacht", "⛵", false),
                QuizOption("3", "Xylophone", "🎼", false)
            )
        )
    )

    // Mini Quiz for Hindi Varnamala (10 Questions)
    val HINDI_QUIZZES: List<QuizQuestion> = listOf(
        QuizQuestion(
            id = 301,
            title = "हिंदी प्रश्न 🍎",
            subtitle = "अ से क्या होता है?",
            itemVisual = "अ",
            options = listOf(
                QuizOption("1", "अनार", "🍎", true),
                QuizOption("2", "आम", "🥭", false),
                QuizOption("3", "हाथी", "🐘", false)
            )
        ),
        QuizQuestion(
            id = 302,
            title = "मीठा फल 🥭",
            subtitle = "आ से क्या होता है?",
            itemVisual = "आ",
            options = listOf(
                QuizOption("1", "इमली", "🌿", false),
                QuizOption("2", "आम", "🥭", true),
                QuizOption("3", "उल्लू", "🦉", false)
            )
        ),
        QuizQuestion(
            id = 303,
            title = "सुंदर पक्षी 🕊️",
            subtitle = "क से क्या होता है?",
            itemVisual = "क",
            options = listOf(
                QuizOption("1", "कबूतर", "🕊️", true),
                QuizOption("2", "खरगोश", "🐰", false),
                QuizOption("3", "गमला", "🪴", false)
            )
        ),
        QuizQuestion(
            id = 304,
            title = "जल की रानी 🐟",
            subtitle = "म से क्या होता है?",
            itemVisual = "म",
            options = listOf(
                QuizOption("1", "मछली", "🐟", true),
                QuizOption("2", "बत्तख", "🦆", false),
                QuizOption("3", "पतंग", "🪁", false)
            )
        ),
        QuizQuestion(
            id = 305,
            title = "खट्टी-मीठी 🌿",
            subtitle = "इ से क्या होता है?",
            itemVisual = "इ",
            options = listOf(
                QuizOption("1", "इमली", "🌿", true),
                QuizOption("2", "ईख", "🎋", false),
                QuizOption("3", "ऊन", "🧶", false)
            )
        ),
        QuizQuestion(
            id = 306,
            title = "रात का राजा 🦉",
            subtitle = "उ से क्या होता है?",
            itemVisual = "उ",
            options = listOf(
                QuizOption("1", "उल्लू", "🦉", true),
                QuizOption("2", "ऋषि", "🧘", false),
                QuizOption("3", "ऐनक", "👓", false)
            )
        ),
        QuizQuestion(
            id = 307,
            title = "लाल-लाल 🍅",
            subtitle = "ट से क्या होता है?",
            itemVisual = "ट",
            options = listOf(
                QuizOption("1", "टमाटर", "🍅", true),
                QuizOption("2", "ठठेरा", "🔨", false),
                QuizOption("3", "डमरू", "🪘", false)
            )
        ),
        QuizQuestion(
            id = 308,
            title = "मीठा तरबूज 🍉",
            subtitle = "त से क्या होता है?",
            itemVisual = "त",
            options = listOf(
                QuizOption("1", "तरबूज", "🍉", true),
                QuizOption("2", "थर्मस", "🫖", false),
                QuizOption("3", "नल", "🚰", false)
            )
        ),
        QuizQuestion(
            id = 309,
            title = "हवा में उड़े 🪁",
            subtitle = "प से क्या होता है?",
            itemVisual = "प",
            options = listOf(
                QuizOption("1", "पतंग", "🪁", true),
                QuizOption("2", "फल", "🍏", false),
                QuizOption("3", "भालू", "🐻", false)
            )
        ),
        QuizQuestion(
            id = 310,
            title = "ज्ञानी महात्मा 🧙‍♂️",
            subtitle = "ज्ञ से क्या होता है?",
            itemVisual = "ज्ञ",
            options = listOf(
                QuizOption("1", "ज्ञानी", "🧙‍♂️", true),
                QuizOption("2", "सूरज", "☀️", false),
                QuizOption("3", "हाथी", "🐘", false)
            )
        )
    )

    // Trophy Challenges
    val TROPHIES: List<TrophyChallenge> = listOf(
        TrophyChallenge(
            tier = "BRONZE",
            title = "🥉 Bronze Trophy Challenge",
            description = "Complete beginner questions in Numbers, ABC, and Hindi!",
            starsReward = 50,
            celebrationMessage = "🎉 Amazing! You earned the Bronze Trophy!",
            requiredScore = 3,
            questions = listOf(
                QuizQuestion(
                    id = 401,
                    title = "Bronze Level 1",
                    subtitle = "How many stars? ⭐ ⭐",
                    itemVisual = "⭐ ⭐",
                    options = listOf(
                        QuizOption("1", "1", "1️⃣", false),
                        QuizOption("2", "2", "2️⃣", true),
                        QuizOption("3", "3", "3️⃣", false)
                    )
                ),
                QuizQuestion(
                    id = 402,
                    title = "Bronze Level 2",
                    subtitle = "Which letter is this? 🅰️",
                    itemVisual = "A",
                    options = listOf(
                        QuizOption("1", "A for Apple", "🍎", true),
                        QuizOption("2", "B for Ball", "⚽", false),
                        QuizOption("3", "C for Cat", "🐱", false)
                    )
                ),
                QuizQuestion(
                    id = 403,
                    title = "Bronze Level 3",
                    subtitle = "अ से क्या होता है? 🍎",
                    itemVisual = "अ",
                    options = listOf(
                        QuizOption("1", "अनार", "🍎", true),
                        QuizOption("2", "उल्लू", "🦉", false),
                        QuizOption("3", "कमल", "🪷", false)
                    )
                )
            )
        ),
        TrophyChallenge(
            tier = "SILVER",
            title = "🥈 Silver Trophy Challenge",
            description = "Complete intermediate challenges with high accuracy!",
            starsReward = 100,
            celebrationMessage = "🌟 Fantastic! You earned the Silver Trophy!",
            requiredScore = 4,
            questions = listOf(
                QuizQuestion(
                    id = 501,
                    title = "Silver Level 1",
                    subtitle = "Count the fruits! 🍎 🍌 🍓 🍇",
                    itemVisual = "🍎 🍌 🍓 🍇",
                    options = listOf(
                        QuizOption("1", "3", "3️⃣", false),
                        QuizOption("2", "4", "4️⃣", true),
                        QuizOption("3", "5", "5️⃣", false)
                    )
                ),
                QuizQuestion(
                    id = 502,
                    title = "Silver Level 2",
                    subtitle = "Which letter starts 'Sun' ☀️?",
                    itemVisual = "☀️ Sun",
                    options = listOf(
                        QuizOption("1", "S", "☀️", true),
                        QuizOption("2", "R", "🌈", false),
                        QuizOption("3", "T", "🐯", false)
                    )
                ),
                QuizQuestion(
                    id = 503,
                    title = "Silver Level 3",
                    subtitle = "क से कबूतर 🕊️ के बाद क्या आता है?",
                    itemVisual = "क ... ?",
                    options = listOf(
                        QuizOption("1", "ग", "🪴", false),
                        QuizOption("2", "ख (खरगोश)", "🐰", true),
                        QuizOption("3", "च", "🥄", false)
                    )
                ),
                QuizQuestion(
                    id = 504,
                    title = "Silver Level 4",
                    subtitle = "What is 3 + 2?",
                    itemVisual = "🍎🍎🍎 + 🍎🍎",
                    options = listOf(
                        QuizOption("1", "4", "4️⃣", false),
                        QuizOption("2", "5", "5️⃣", true),
                        QuizOption("3", "6", "6️⃣", false)
                    )
                )
            )
        ),
        TrophyChallenge(
            tier = "GOLDEN",
            title = "🥇 Golden Trophy Challenge",
            description = "Master all skills to become a Super Champion!",
            starsReward = 250,
            celebrationMessage = "🏆 WOW! You are a Super Champion!",
            requiredScore = 5,
            questions = listOf(
                QuizQuestion(
                    id = 601,
                    title = "Golden Champion 1",
                    subtitle = "Count all puppies! 🐶 🐶 🐶 🐶 🐶 🐶",
                    itemVisual = "🐶 🐶 🐶 🐶 🐶 🐶",
                    options = listOf(
                        QuizOption("1", "5", "5️⃣", false),
                        QuizOption("2", "6", "6️⃣", true),
                        QuizOption("3", "7", "7️⃣", false)
                    )
                ),
                QuizQuestion(
                    id = 602,
                    title = "Golden Champion 2",
                    subtitle = "Spell the animal: E-L-E-P-H-A-N-T",
                    itemVisual = "🐘 Elephant",
                    options = listOf(
                        QuizOption("1", "E", "🐘", true),
                        QuizOption("2", "O", "🦉", false),
                        QuizOption("3", "H", "🐴", false)
                    )
                ),
                QuizQuestion(
                    id = 603,
                    title = "Golden Champion 3",
                    subtitle = "ज्ञ से क्या होता है? 🧙‍♂️",
                    itemVisual = "ज्ञ",
                    options = listOf(
                        QuizOption("1", "ज्ञानी", "🧙‍♂️", true),
                        QuizOption("2", "राजा", "👑", false),
                        QuizOption("3", "सूरज", "☀️", false)
                    )
                ),
                QuizQuestion(
                    id = 604,
                    title = "Golden Champion 4",
                    subtitle = "10 in Hindi is called:",
                    itemVisual = "🔟",
                    options = listOf(
                        QuizOption("1", "पाँच", "5️⃣", false),
                        QuizOption("2", "दस", "🔟", true),
                        QuizOption("3", "बीस", "2️⃣0️⃣", false)
                    )
                ),
                QuizQuestion(
                    id = 605,
                    title = "Golden Champion 5",
                    subtitle = "Match Z: Z for ...?",
                    itemVisual = "🦓 Zebra",
                    options = listOf(
                        QuizOption("1", "Zebra", "🦓", true),
                        QuizOption("2", "Yacht", "⛵", false),
                        QuizOption("3", "Fox", "🦊", false)
                    )
                )
            )
        )
    )
}
