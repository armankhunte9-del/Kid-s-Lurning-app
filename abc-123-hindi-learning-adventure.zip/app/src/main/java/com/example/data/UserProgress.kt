package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_progress")
data class UserProgress(
    @PrimaryKey val id: Int = 1,
    val stars: Int = 0,
    val numbersProgress: Int = 1, // Current max number unlocked/viewed (1..100)
    val abcProgress: Int = 1,     // Current max letter unlocked (1..26)
    val hindiProgress: Int = 1,   // Current max Hindi letter unlocked (1..52)
    val gamesPlayed: Int = 0,
    val lessonsCompleted: Int = 0,
    val quizTotalScore: Int = 0,
    val bronzeTrophyUnlocked: Boolean = false,
    val silverTrophyUnlocked: Boolean = false,
    val goldenTrophyUnlocked: Boolean = false,
    val soundEffectsEnabled: Boolean = true,
    val voiceEnabled: Boolean = true,
    val musicEnabled: Boolean = true,
    val selectedLanguage: String = "BILINGUAL", // BILINGUAL, ENGLISH, HINDI
    val totalLearningMinutes: Int = 5,
    val hasCompletedOnboarding: Boolean = false,
    val lastUpdated: Long = System.currentTimeMillis()
) {
    val hasBronzeTrophy: Boolean get() = bronzeTrophyUnlocked
    val hasSilverTrophy: Boolean get() = silverTrophyUnlocked
    val hasGoldTrophy: Boolean get() = goldenTrophyUnlocked
}
