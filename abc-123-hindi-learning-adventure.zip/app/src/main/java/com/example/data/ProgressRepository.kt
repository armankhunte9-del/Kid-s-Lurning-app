package com.example.data

import kotlinx.coroutines.flow.Flow

class ProgressRepository(private val progressDao: ProgressDao) {

    val userProgress: Flow<UserProgress?> = progressDao.getProgress()

    suspend fun ensureInitialized() {
        val existing = progressDao.getProgressOnce()
        if (existing == null) {
            progressDao.saveProgress(UserProgress(id = 1))
        }
    }

    suspend fun saveProgress(progress: UserProgress) {
        progressDao.saveProgress(progress)
    }

    suspend fun addStars(delta: Int) {
        progressDao.addStars(delta)
    }

    suspend fun recordGamePlayed(earnedStars: Int = 10) {
        progressDao.incrementGamesPlayed()
        if (earnedStars > 0) {
            progressDao.addStars(earnedStars)
        }
    }

    suspend fun recordLessonCompleted(earnedStars: Int = 25) {
        progressDao.incrementLessonsCompleted()
        if (earnedStars > 0) {
            progressDao.addStars(earnedStars)
        }
    }

    suspend fun unlockTrophy(trophyTier: String) {
        when (trophyTier.uppercase()) {
            "BRONZE" -> {
                progressDao.unlockBronze()
                progressDao.addStars(50)
            }
            "SILVER" -> {
                progressDao.unlockSilver()
                progressDao.addStars(100)
            }
            "GOLD", "GOLDEN" -> {
                progressDao.unlockGold()
                progressDao.addStars(250)
            }
        }
    }

    suspend fun updateSettings(sound: Boolean, voice: Boolean, music: Boolean, lang: String) {
        progressDao.setSoundEffects(sound)
        progressDao.setVoice(voice)
        progressDao.setMusic(music)
        progressDao.setLanguage(lang)
    }

    suspend fun setOnboardingCompleted() {
        progressDao.completeOnboarding()
    }

    suspend fun resetProgress() {
        progressDao.clearProgress()
        progressDao.saveProgress(UserProgress(id = 1, stars = 0))
    }
}
