package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ProgressDao {
    @Query("SELECT * FROM user_progress WHERE id = 1 LIMIT 1")
    fun getProgress(): Flow<UserProgress?>

    @Query("SELECT * FROM user_progress WHERE id = 1 LIMIT 1")
    suspend fun getProgressOnce(): UserProgress?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProgress(progress: UserProgress)

    @Query("UPDATE user_progress SET stars = stars + :starDelta WHERE id = 1")
    suspend fun addStars(starDelta: Int)

    @Query("UPDATE user_progress SET gamesPlayed = gamesPlayed + 1 WHERE id = 1")
    suspend fun incrementGamesPlayed()

    @Query("UPDATE user_progress SET lessonsCompleted = lessonsCompleted + 1 WHERE id = 1")
    suspend fun incrementLessonsCompleted()

    @Query("UPDATE user_progress SET bronzeTrophyUnlocked = 1 WHERE id = 1")
    suspend fun unlockBronze()

    @Query("UPDATE user_progress SET silverTrophyUnlocked = 1 WHERE id = 1")
    suspend fun unlockSilver()

    @Query("UPDATE user_progress SET goldenTrophyUnlocked = 1 WHERE id = 1")
    suspend fun unlockGold()

    @Query("UPDATE user_progress SET soundEffectsEnabled = :enabled WHERE id = 1")
    suspend fun setSoundEffects(enabled: Boolean)

    @Query("UPDATE user_progress SET musicEnabled = :enabled WHERE id = 1")
    suspend fun setMusic(enabled: Boolean)

    @Query("UPDATE user_progress SET voiceEnabled = :enabled WHERE id = 1")
    suspend fun setVoice(enabled: Boolean)

    @Query("UPDATE user_progress SET selectedLanguage = :lang WHERE id = 1")
    suspend fun setLanguage(lang: String)

    @Query("UPDATE user_progress SET hasCompletedOnboarding = 1 WHERE id = 1")
    suspend fun completeOnboarding()

    @Query("DELETE FROM user_progress")
    suspend fun clearProgress()
}
