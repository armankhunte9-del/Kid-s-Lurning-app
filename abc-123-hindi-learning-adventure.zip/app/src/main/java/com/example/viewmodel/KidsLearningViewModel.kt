package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.SoundManager
import com.example.data.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class AppScreen {
    SPLASH,
    ONBOARDING,
    HOME,
    NUMBERS,
    ALPHABET,
    HINDI,
    GAMES,
    TROPHIES,
    REWARDS,
    PARENT_DASHBOARD,
    SETTINGS
}

enum class MiniGameType {
    FIND_ANSWER,
    NUMBER_COUNTING,
    MATCH_PAIR,
    HINDI_LETTER,
    MEMORY_CARDS
}

data class ParentGateQuestion(
    val num1: Int,
    val num2: Int,
    val answer: Int
)

class KidsLearningViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ProgressRepository
    val soundManager: SoundManager = SoundManager(application)

    val progress: StateFlow<UserProgress>
    private val _currentScreen = MutableStateFlow(AppScreen.SPLASH)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    // Splash / Onboarding state
    private val _onboardingStep = MutableStateFlow(0)
    val onboardingStep: StateFlow<Int> = _onboardingStep.asStateFlow()

    // Numbers Level State
    private val _numberIndex = MutableStateFlow(0)
    val numberIndex: StateFlow<Int> = _numberIndex.asStateFlow()

    private val _numberQuizIndex = MutableStateFlow(0)
    val numberQuizIndex: StateFlow<Int> = _numberQuizIndex.asStateFlow()
    private val _isNumberQuizMode = MutableStateFlow(false)
    val isNumberQuizMode: StateFlow<Boolean> = _isNumberQuizMode.asStateFlow()

    // Alphabet Level State
    private val _alphabetIndex = MutableStateFlow(0)
    val alphabetIndex: StateFlow<Int> = _alphabetIndex.asStateFlow()
    private val _alphabetQuizIndex = MutableStateFlow(0)
    val alphabetQuizIndex: StateFlow<Int> = _alphabetQuizIndex.asStateFlow()
    private val _isAlphabetQuizMode = MutableStateFlow(false)
    val isAlphabetQuizMode: StateFlow<Boolean> = _isAlphabetQuizMode.asStateFlow()

    // Hindi Level State
    private val _hindiIndex = MutableStateFlow(0)
    val hindiIndex: StateFlow<Int> = _hindiIndex.asStateFlow()
    private val _hindiQuizIndex = MutableStateFlow(0)
    val hindiQuizIndex: StateFlow<Int> = _hindiQuizIndex.asStateFlow()
    private val _isHindiQuizMode = MutableStateFlow(false)
    val isHindiQuizMode: StateFlow<Boolean> = _isHindiQuizMode.asStateFlow()

    // Games State
    private val _selectedGame = MutableStateFlow(MiniGameType.FIND_ANSWER)
    val selectedGame: StateFlow<MiniGameType> = _selectedGame.asStateFlow()

    // Game 1: Find Answer State
    private val _findAnswerScore = MutableStateFlow(0)
    val findAnswerScore: StateFlow<Int> = _findAnswerScore.asStateFlow()
    private val _findAnswerQuestionIndex = MutableStateFlow(0)
    val findAnswerQuestionIndex: StateFlow<Int> = _findAnswerQuestionIndex.asStateFlow()

    // Game 2: Counting Game State
    private val _countingTarget = MutableStateFlow(4)
    val countingTarget: StateFlow<Int> = _countingTarget.asStateFlow()
    private val _countingEmoji = MutableStateFlow("🍎")
    val countingEmoji: StateFlow<String> = _countingEmoji.asStateFlow()
    private val _countingOptions = MutableStateFlow(listOf(3, 4, 5))
    val countingOptions: StateFlow<List<Int>> = _countingOptions.asStateFlow()

    // Game 3: Match Pair State
    private val _selectedMatchLeft = MutableStateFlow<String?>(null)
    val selectedMatchLeft: StateFlow<String?> = _selectedMatchLeft.asStateFlow()
    private val _matchedPairIds = MutableStateFlow<Set<String>>(emptySet())
    val matchedPairIds: StateFlow<Set<String>> = _matchedPairIds.asStateFlow()

    // Game 4: Hindi Letter Game
    private val _hindiGameTargetIndex = MutableStateFlow(0)
    val hindiGameTargetIndex: StateFlow<Int> = _hindiGameTargetIndex.asStateFlow()
    private val _hindiGameOptions = MutableStateFlow(listOf<String>())
    val hindiGameOptions: StateFlow<List<String>> = _hindiGameOptions.asStateFlow()

    // Game 5: Memory Cards State
    private val _memoryCards = MutableStateFlow<List<MemoryCard>>(emptyList())
    val memoryCards: StateFlow<List<MemoryCard>> = _memoryCards.asStateFlow()
    private var firstFlippedIndex: Int? = null
    private var isProcessingFlip = false

    // Trophy Challenge State
    private val _selectedTrophyTier = MutableStateFlow("BRONZE")
    val selectedTrophyTier: StateFlow<String> = _selectedTrophyTier.asStateFlow()
    private val _trophyQuestionIndex = MutableStateFlow(0)
    val trophyQuestionIndex: StateFlow<Int> = _trophyQuestionIndex.asStateFlow()
    private val _trophyScore = MutableStateFlow(0)
    val trophyScore: StateFlow<Int> = _trophyScore.asStateFlow()
    private val _trophyCelebrationTier = MutableStateFlow<String?>(null)
    val trophyCelebrationTier: StateFlow<String?> = _trophyCelebrationTier.asStateFlow()

    // Celebration & Confetti Trigger
    private val _confettiTrigger = MutableStateFlow(0)
    val confettiTrigger: StateFlow<Int> = _confettiTrigger.asStateFlow()
    private val _feedbackToast = MutableStateFlow<String?>(null)
    val feedbackToast: StateFlow<String?> = _feedbackToast.asStateFlow()

    // Parent Gate
    private val _parentGateQuestion = MutableStateFlow(ParentGateQuestion(3, 4, 7))
    val parentGateQuestion: StateFlow<ParentGateQuestion> = _parentGateQuestion.asStateFlow()
    private val _isParentGateOpen = MutableStateFlow(false)
    val isParentGateOpen: StateFlow<Boolean> = _isParentGateOpen.asStateFlow()

    init {
        val database = AppDatabase.getDatabase(application)
        repository = ProgressRepository(database.progressDao())

        progress = repository.userProgress
            .filterNotNull()
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000),
                initialValue = UserProgress()
            )

        viewModelScope.launch {
            repository.ensureInitialized()
            progress.collect { prog ->
                soundManager.soundEffectsEnabled = prog.soundEffectsEnabled
                soundManager.voiceEnabled = prog.voiceEnabled
                soundManager.musicEnabled = prog.musicEnabled
            }
        }

        initCountingGame()
        initHindiGame()
        initMemoryGame()

        // Splash auto-transition
        viewModelScope.launch {
            delay(2400)
            if (_currentScreen.value == AppScreen.SPLASH) {
                val hasCompleted = progress.value.hasCompletedOnboarding
                if (hasCompleted) {
                    _currentScreen.value = AppScreen.HOME
                } else {
                    _currentScreen.value = AppScreen.ONBOARDING
                }
            }
        }
    }

    fun navigateTo(screen: AppScreen) {
        soundManager.playTapSound()
        _currentScreen.value = screen
    }

    fun nextOnboardingStep() {
        soundManager.playTapSound()
        if (_onboardingStep.value < 2) {
            _onboardingStep.value += 1
        } else {
            finishOnboarding()
        }
    }

    fun finishOnboarding() {
        soundManager.playCorrectSound()
        viewModelScope.launch {
            repository.setOnboardingCompleted()
        }
        _currentScreen.value = AppScreen.HOME
    }

    // --- Numbers Section ---
    fun selectNumber(index: Int) {
        val bounded = index.coerceIn(0, KidsLearningData.NUMBERS.size - 1)
        _numberIndex.value = bounded
        speakCurrentNumber()
    }

    fun nextNumber() {
        soundManager.playTapSound()
        if (_numberIndex.value < KidsLearningData.NUMBERS.size - 1) {
            _numberIndex.value += 1
            speakCurrentNumber()
        }
    }

    fun prevNumber() {
        soundManager.playTapSound()
        if (_numberIndex.value > 0) {
            _numberIndex.value -= 1
            speakCurrentNumber()
        }
    }

    fun speakCurrentNumber() {
        val item = KidsLearningData.NUMBERS[_numberIndex.value]
        val lang = progress.value.selectedLanguage
        soundManager.speakNumber(item.number, item.englishWord, item.hindiWord, lang)
    }

    fun toggleNumberQuiz(show: Boolean) {
        soundManager.playTapSound()
        _isNumberQuizMode.value = show
        if (show) {
            _numberQuizIndex.value = 0
        }
    }

    fun answerNumberQuiz(option: QuizOption) {
        if (option.isCorrect) {
            triggerSuccess("🎉 Great Job! +10 Stars ⭐")
            viewModelScope.launch {
                repository.addStars(10)
                repository.recordLessonCompleted(10)
            }
            if (_numberQuizIndex.value < KidsLearningData.NUMBER_QUIZZES.size - 1) {
                _numberQuizIndex.value += 1
            } else {
                triggerSuccess("🎉 Level Finished! +25 Stars ⭐")
                viewModelScope.launch { repository.addStars(25) }
                _isNumberQuizMode.value = false
            }
        } else {
            triggerWrong("😊 Try Again!")
        }
    }

    // --- Alphabet Section ---
    fun selectAlphabet(index: Int) {
        val bounded = index.coerceIn(0, KidsLearningData.ALPHABETS.size - 1)
        _alphabetIndex.value = bounded
        speakCurrentAlphabet()
    }

    fun nextAlphabet() {
        soundManager.playTapSound()
        if (_alphabetIndex.value < KidsLearningData.ALPHABETS.size - 1) {
            _alphabetIndex.value += 1
            speakCurrentAlphabet()
        }
    }

    fun prevAlphabet() {
        soundManager.playTapSound()
        if (_alphabetIndex.value > 0) {
            _alphabetIndex.value -= 1
            speakCurrentAlphabet()
        }
    }

    fun speakCurrentAlphabet() {
        val item = KidsLearningData.ALPHABETS[_alphabetIndex.value]
        soundManager.speakAlphabet(item.letter, item.word)
    }

    fun toggleAlphabetQuiz(show: Boolean) {
        soundManager.playTapSound()
        _isAlphabetQuizMode.value = show
        if (show) {
            _alphabetQuizIndex.value = 0
        }
    }

    fun answerAlphabetQuiz(option: QuizOption) {
        if (option.isCorrect) {
            triggerSuccess("🎉 Correct! +10 Stars ⭐")
            viewModelScope.launch {
                repository.addStars(10)
                repository.recordLessonCompleted(10)
            }
            if (_alphabetQuizIndex.value < KidsLearningData.ALPHABET_QUIZZES.size - 1) {
                _alphabetQuizIndex.value += 1
            } else {
                triggerSuccess("🎉 Alphabet Master! +25 Stars ⭐")
                viewModelScope.launch { repository.addStars(25) }
                _isAlphabetQuizMode.value = false
            }
        } else {
            triggerWrong("😊 Try Again!")
        }
    }

    // --- Hindi Varnamala Section ---
    fun selectHindiLetter(index: Int) {
        val bounded = index.coerceIn(0, KidsLearningData.HINDI_VARNAMALA.size - 1)
        _hindiIndex.value = bounded
        speakCurrentHindiLetter()
    }

    fun nextHindiLetter() {
        soundManager.playTapSound()
        if (_hindiIndex.value < KidsLearningData.HINDI_VARNAMALA.size - 1) {
            _hindiIndex.value += 1
            speakCurrentHindiLetter()
        }
    }

    fun prevHindiLetter() {
        soundManager.playTapSound()
        if (_hindiIndex.value > 0) {
            _hindiIndex.value -= 1
            speakCurrentHindiLetter()
        }
    }

    fun speakCurrentHindiLetter() {
        val item = KidsLearningData.HINDI_VARNAMALA[_hindiIndex.value]
        soundManager.speakHindiLetter(item.letter, item.word)
    }

    fun toggleHindiQuiz(show: Boolean) {
        soundManager.playTapSound()
        _isHindiQuizMode.value = show
        if (show) {
            _hindiQuizIndex.value = 0
        }
    }

    fun answerHindiQuiz(option: QuizOption) {
        if (option.isCorrect) {
            triggerSuccess("🎉 बहुत बढ़िया! Great! +10 Stars ⭐")
            viewModelScope.launch {
                repository.addStars(10)
                repository.recordLessonCompleted(10)
            }
            if (_hindiQuizIndex.value < KidsLearningData.HINDI_QUIZZES.size - 1) {
                _hindiQuizIndex.value += 1
            } else {
                triggerSuccess("🎉 Hindi Level Complete! +25 Stars ⭐")
                viewModelScope.launch { repository.addStars(25) }
                _isHindiQuizMode.value = false
            }
        } else {
            triggerWrong("😊 फिर कोशिश करो! Try Again!")
        }
    }

    // --- Games Section ---
    fun selectMiniGame(game: MiniGameType) {
        soundManager.playTapSound()
        _selectedGame.value = game
        when (game) {
            MiniGameType.FIND_ANSWER -> {
                _findAnswerQuestionIndex.value = 0
                _findAnswerScore.value = 0
            }
            MiniGameType.NUMBER_COUNTING -> initCountingGame()
            MiniGameType.MATCH_PAIR -> {
                _selectedMatchLeft.value = null
                _matchedPairIds.value = emptySet()
            }
            MiniGameType.HINDI_LETTER -> initHindiGame()
            MiniGameType.MEMORY_CARDS -> initMemoryGame()
        }
    }

    fun answerFindGame(option: QuizOption) {
        if (option.isCorrect) {
            triggerSuccess("⭐ +10 Points!")
            _findAnswerScore.value += 10
            viewModelScope.launch { repository.recordGamePlayed(10) }
            if (_findAnswerQuestionIndex.value < KidsLearningData.ALPHABET_QUIZZES.size - 1) {
                _findAnswerQuestionIndex.value += 1
            } else {
                triggerSuccess("🎉 Game Finished! Champion!")
                _findAnswerQuestionIndex.value = 0
            }
        } else {
            triggerWrong("😊 Try Again!")
        }
    }

    fun initCountingGame() {
        val emojis = listOf("🍎", "🍌", "⭐", "🎈", "🚗", "🐶", "🍓")
        val target = Random.nextInt(2, 7)
        _countingTarget.value = target
        _countingEmoji.value = emojis.random()
        val other1 = (target + 1).coerceAtMost(8)
        val other2 = (target - 1).coerceAtLeast(1)
        _countingOptions.value = listOf(target, other1, other2).shuffled()
    }

    fun answerCountingGame(selectedNum: Int) {
        if (selectedNum == _countingTarget.value) {
            triggerSuccess("🎉 Correct Counting! +10 Stars ⭐")
            viewModelScope.launch { repository.recordGamePlayed(10) }
            initCountingGame()
        } else {
            triggerWrong("😊 Try Again!")
        }
    }

    fun selectMatchKey(key: String) {
        soundManager.playTapSound()
        _selectedMatchLeft.value = key
    }

    fun selectMatchTarget(pairItem: MatchPairItem) {
        val currentKey = _selectedMatchLeft.value
        if (currentKey == null) {
            soundManager.playTapSound()
            return
        }

        if (currentKey == pairItem.keyText) {
            triggerSuccess("🎉 Pair Matched! +10 Stars ⭐")
            _matchedPairIds.value = _matchedPairIds.value + pairItem.id
            _selectedMatchLeft.value = null
            viewModelScope.launch { repository.recordGamePlayed(10) }

            if (_matchedPairIds.value.size >= 4) {
                triggerSuccess("🎉 All Pairs Matched! Superb! +20 Stars ⭐")
                viewModelScope.launch { repository.addStars(20) }
            }
        } else {
            triggerWrong("😊 Try matching the right one!")
            _selectedMatchLeft.value = null
        }
    }

    fun initHindiGame() {
        val targetIdx = Random.nextInt(0, KidsLearningData.HINDI_VARNAMALA.size)
        _hindiGameTargetIndex.value = targetIdx
        val targetLetter = KidsLearningData.HINDI_VARNAMALA[targetIdx].letter

        val other1 = KidsLearningData.HINDI_VARNAMALA[(targetIdx + 3) % KidsLearningData.HINDI_VARNAMALA.size].letter
        val other2 = KidsLearningData.HINDI_VARNAMALA[(targetIdx + 7) % KidsLearningData.HINDI_VARNAMALA.size].letter

        _hindiGameOptions.value = listOf(targetLetter, other1, other2).shuffled()
    }

    fun answerHindiGame(selectedLetter: String) {
        val targetLetter = KidsLearningData.HINDI_VARNAMALA[_hindiGameTargetIndex.value].letter
        if (selectedLetter == targetLetter) {
            triggerSuccess("🎉 सही उत्तर! Correct! +10 Stars ⭐")
            viewModelScope.launch { repository.recordGamePlayed(10) }
            initHindiGame()
        } else {
            triggerWrong("😊 Try Again!")
        }
    }

    fun initMemoryGame() {
        firstFlippedIndex = null
        isProcessingFlip = false
        data class MemoryItem(val text: String, val emoji: String, val color: androidx.compose.ui.graphics.Color)
        val samplePairs = listOf(
            MemoryItem("A", "🍎", KidsRed),
            MemoryItem("B", "⚽", KidsBlue),
            MemoryItem("C", "🐱", KidsOrange),
            MemoryItem("अ", "🍎", KidsPink)
        )

        val cards = mutableListOf<MemoryCard>()
        var idCounter = 0
        samplePairs.forEachIndexed { pairIndex, item ->
            cards.add(MemoryCard(id = idCounter++, pairId = pairIndex, displayContent = item.text, isEmoji = false, title = item.text, isFlipped = false, isMatched = false, color = item.color))
            cards.add(MemoryCard(id = idCounter++, pairId = pairIndex, displayContent = item.emoji, isEmoji = true, title = item.text, isFlipped = false, isMatched = false, color = item.color))
        }
        _memoryCards.value = cards.shuffled()
    }

    fun flipMemoryCard(cardIndex: Int) {
        if (isProcessingFlip) return
        val currentCards = _memoryCards.value.toMutableList()
        val card = currentCards.getOrNull(cardIndex) ?: return

        if (card.isFlipped || card.isMatched) return

        soundManager.playTapSound()
        card.isFlipped = true
        _memoryCards.value = currentCards

        if (firstFlippedIndex == null) {
            firstFlippedIndex = cardIndex
        } else {
            val firstIndex = firstFlippedIndex!!
            firstFlippedIndex = null
            isProcessingFlip = true

            val firstCard = currentCards[firstIndex]
            if (firstCard.pairId == card.pairId) {
                // Matched!
                triggerSuccess("✨ Matched! +10 Stars ⭐")
                firstCard.isMatched = true
                card.isMatched = true
                _memoryCards.value = currentCards
                isProcessingFlip = false
                viewModelScope.launch { repository.recordGamePlayed(10) }

                if (currentCards.all { it.isMatched }) {
                    triggerSuccess("🏆 Memory Master! +30 Stars ⭐")
                    viewModelScope.launch { repository.addStars(30) }
                }
            } else {
                // Not matched -> flip back after delay
                soundManager.playWrongSound()
                viewModelScope.launch {
                    delay(900)
                    firstCard.isFlipped = false
                    card.isFlipped = false
                    _memoryCards.value = currentCards
                    isProcessingFlip = false
                }
            }
        }
    }

    // --- Trophy Challenge Section ---
    fun startTrophyChallenge(tier: String) {
        soundManager.playTapSound()
        _selectedTrophyTier.value = tier
        _trophyQuestionIndex.value = 0
        _trophyScore.value = 0
        _trophyCelebrationTier.value = null
    }

    fun answerTrophyQuestion(option: QuizOption) {
        val currentChallenge = KidsLearningData.TROPHIES.firstOrNull { it.tier == _selectedTrophyTier.value }
            ?: return

        if (option.isCorrect) {
            triggerSuccess("🎉 Correct!")
            _trophyScore.value += 1
        } else {
            triggerWrong("😊 Keep Going!")
        }

        if (_trophyQuestionIndex.value < currentChallenge.questions.size - 1) {
            _trophyQuestionIndex.value += 1
        } else {
            // Challenge Completed Check
            val finalScore = _trophyScore.value
            if (finalScore >= currentChallenge.requiredScore) {
                soundManager.playTrophyCelebration()
                _trophyCelebrationTier.value = currentChallenge.tier
                _confettiTrigger.value += 1
                viewModelScope.launch {
                    repository.unlockTrophy(currentChallenge.tier)
                }
            } else {
                triggerWrong("Score: $finalScore/${currentChallenge.questions.size}. Try again to earn the trophy!")
            }
        }
    }

    fun dismissTrophyCelebration() {
        soundManager.playTapSound()
        _trophyCelebrationTier.value = null
    }

    // --- Parent Gate & Dashboard ---
    fun generateParentGateQuestion() {
        val a = Random.nextInt(2, 9)
        val b = Random.nextInt(2, 9)
        _parentGateQuestion.value = ParentGateQuestion(a, b, a + b)
        _isParentGateOpen.value = true
    }

    fun closeParentGate() {
        _isParentGateOpen.value = false
    }

    fun verifyParentGateAnswer(enteredAnswer: String): Boolean {
        val isCorrect = enteredAnswer.trim() == _parentGateQuestion.value.answer.toString()
        if (isCorrect) {
            _isParentGateOpen.value = false
            soundManager.playCorrectSound()
            _currentScreen.value = AppScreen.PARENT_DASHBOARD
        } else {
            soundManager.playWrongSound()
        }
        return isCorrect
    }

    // --- Settings Updates ---
    fun toggleSoundEffects(enabled: Boolean) {
        soundManager.soundEffectsEnabled = enabled
        viewModelScope.launch {
            repository.updateSettings(
                sound = enabled,
                voice = progress.value.voiceEnabled,
                music = progress.value.musicEnabled,
                lang = progress.value.selectedLanguage
            )
        }
    }

    fun toggleVoice(enabled: Boolean) {
        soundManager.voiceEnabled = enabled
        viewModelScope.launch {
            repository.updateSettings(
                sound = progress.value.soundEffectsEnabled,
                voice = enabled,
                music = progress.value.musicEnabled,
                lang = progress.value.selectedLanguage
            )
        }
    }

    fun toggleMusic(enabled: Boolean) {
        soundManager.musicEnabled = enabled
        viewModelScope.launch {
            repository.updateSettings(
                sound = progress.value.soundEffectsEnabled,
                voice = progress.value.voiceEnabled,
                music = enabled,
                lang = progress.value.selectedLanguage
            )
        }
    }

    fun setLanguage(lang: String) {
        soundManager.playTapSound()
        viewModelScope.launch {
            repository.updateSettings(
                sound = progress.value.soundEffectsEnabled,
                voice = progress.value.voiceEnabled,
                music = progress.value.musicEnabled,
                lang = lang
            )
        }
    }

    fun resetAllProgress() {
        soundManager.playTapSound()
        viewModelScope.launch {
            repository.resetProgress()
            _numberIndex.value = 0
            _alphabetIndex.value = 0
            _hindiIndex.value = 0
        }
    }

    private fun triggerSuccess(message: String) {
        soundManager.playCorrectSound()
        _confettiTrigger.value += 1
        _feedbackToast.value = message
        viewModelScope.launch {
            delay(2000)
            if (_feedbackToast.value == message) {
                _feedbackToast.value = null
            }
        }
    }

    private fun triggerWrong(message: String) {
        soundManager.playWrongSound()
        _feedbackToast.value = message
        viewModelScope.launch {
            delay(2000)
            if (_feedbackToast.value == message) {
                _feedbackToast.value = null
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        soundManager.release()
    }
}
